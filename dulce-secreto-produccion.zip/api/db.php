<?php
/**
 * ======================================================================
 * DULCE SECRETO — CONECTOR PDO MYSQL CON FALLBACK AUTOMÁTICO A DISCO
 * ======================================================================
 */

require_once __DIR__ . '/config.php';

function getDatabaseConnection() {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    // Si no se han configurado credenciales reales, retorna null para usar fallback a disco JSON
    if (DB_NAME === 'u123456789_dulcesecreto') {
        return null;
    }

    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo;
    } catch (PDOException $e) {
        // En caso de fallo de conexión a MySQL, se registra el error y se usa fallback
        error_log('[DB Error Dulce Secreto] ' . $e->getMessage());
        return null;
    }
}
