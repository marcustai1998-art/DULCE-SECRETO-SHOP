<?php
/**
 * ======================================================================
 * DULCE SECRETO — OBTENER CONFIGURACIÓN
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');

$configPath = __DIR__ . '/../store-config.json';
if (file_exists($configPath)) {
    echo file_get_contents($configPath);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Configuración no encontrada']);
}
