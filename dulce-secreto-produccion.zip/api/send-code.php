<?php
/**
 * ======================================================================
 * DULCE SECRETO — ENVÍO DE CÓDIGO DE VERIFICACIÓN ADMIN
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/config.php';

$rawInput = file_get_contents('php://input');
$body = json_decode($rawInput, true);
$targetEmail = $body['email'] ?? ADMIN_EMAIL;

// Generar código numérico de 6 dígitos
$code = strval(mt_rand(100000, 999999));

// Intentar envío por correo si la función mail() está activa en Hostinger
$subject = "Tu Código de Acceso - Dulce Secreto Admin";
$message = "Hola,\n\nTu código de verificación para ingresar al Panel Administrativo de Dulce Secreto es:\n\n$code\n\nEste código expira en 10 minutos.";
$headers = "From: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'dulcesecreto.com') . "\r\n" .
           "Reply-To: " . ADMIN_EMAIL . "\r\n" .
           "X-Mailer: PHP/" . phpversion();

@mail($targetEmail, $subject, $message, $headers);

// Retornar en JSON para desarrollo y fallback
echo json_encode([
    'success' => true,
    'message' => 'Código de verificación generado con éxito',
    'code'    => $code, // Código visible para autofill en la UI
    'email'   => $targetEmail
]);
