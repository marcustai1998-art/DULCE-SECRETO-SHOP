<?php
/**
 * ======================================================================
 * DULCE SECRETO — OBTENER PRODUCTOS (MYSQL + FALLBACK JSON)
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

require_once __DIR__ . '/db.php';

$pdo = getDatabaseConnection();

// 1. Si MySQL está activo y conectado, consultar base de datos
if ($pdo !== null) {
    try {
        $stmt = $pdo->query("SELECT * FROM `productos` ORDER BY `category` ASC, `regularPrice` DESC");
        $rows = $stmt->fetchAll();

        if (!empty($rows)) {
            $products = array_map(function ($row) {
                return [
                    'id'           => $row['id'],
                    'name'         => $row['name'],
                    'category'     => $row['category'],
                    'regularPrice' => (int)$row['regularPrice'],
                    'salePrice'    => (int)$row['salePrice'],
                    'isFlashSale'  => (bool)$row['isFlashSale'],
                    'rating'       => (float)$row['rating'],
                    'reviewsCount' => (int)$row['reviewsCount'],
                    'salesCount'   => (int)$row['salesCount'],
                    'tags'         => json_decode($row['tags'] ?? '[]', true) ?: [],
                    'description'  => $row['description'] ?? '',
                    'composition'  => $row['composition'] ?? '',
                    'sizes'        => json_decode($row['sizes'] ?? '[]', true) ?: [],
                    'images'       => json_decode($row['images'] ?? '[]', true) ?: [],
                    'crossSellIds' => json_decode($row['crossSellIds'] ?? '[]', true) ?: [],
                ];
            }, $rows);

            echo json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
            exit;
        }
    } catch (Exception $e) {
        error_log('[API Products Error] ' . $e->getMessage());
    }
}

// 2. Fallback resiliente: Leer archivo store-products.json en disco
$jsonPath = __DIR__ . '/../store-products.json';
if (file_exists($jsonPath)) {
    echo file_get_contents($jsonPath);
} else {
    http_response_code(404);
    echo json_encode(['error' => 'Catálogo no encontrado']);
}
