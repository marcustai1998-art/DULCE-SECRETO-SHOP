<?php
/**
 * ======================================================================
 * DULCE SECRETO — SUBIDA PERSISTENTE DE IMÁGENES A DISCO EN HOSTINGER
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$targetDir = __DIR__ . '/../images/products/';

if (!is_dir($targetDir)) {
    mkdir($targetDir, 0755, true);
}

// 1. Caso A: Subida estándar multipart/form-data
if (isset($_FILES['file']) || isset($_FILES['image'])) {
    $fileObj = $_FILES['file'] ?? $_FILES['image'];

    if ($fileObj['error'] !== UPLOAD_ERR_OK) {
        http_response_code(400);
        echo json_encode(['error' => 'Error en la subida del archivo (Código ' . $fileObj['error'] . ')']);
        exit;
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mimeType = finfo_file($finfo, $fileObj['tmp_name']);
    finfo_close($finfo);

    $allowedMimes = [
        'image/jpeg' => '.jpg',
        'image/png'  => '.png',
        'image/webp' => '.webp',
    ];

    if (!isset($allowedMimes[$mimeType])) {
        http_response_code(400);
        echo json_encode(['error' => 'Formato no permitido. Solo se aceptan imágenes JPG, PNG o WebP.']);
        exit;
    }

    $ext = $allowedMimes[$mimeType];
    $filename = 'foto-slot-' . round(microtime(true) * 1000) . '-' . mt_rand(100, 999) . $ext;
    $destination = $targetDir . $filename;

    if (move_uploaded_file($fileObj['tmp_name'], $destination)) {
        chmod($destination, 0644);
        echo json_encode([
            'success' => true,
            'url'     => 'images/products/' . $filename,
            'message' => 'Imagen almacenada permanentemente en el servidor'
        ]);
        exit;
    } else {
        http_response_code(500);
        echo json_encode(['error' => 'No se pudo mover la imagen al directorio final']);
        exit;
    }
}

// 2. Caso B: Subida en Base64 (JSON)
$rawInput = file_get_contents('php://input');
$body = json_decode($rawInput, true);

if (!empty($body['image']) || !empty($body['base64']) || !empty($body['imageData'])) {
    $dataUri = $body['image'] ?? $body['base64'] ?? $body['imageData'];
    $folder = (!empty($body['folder']) && $body['folder'] === 'banners') ? 'banners' : 'products';
    $targetDir = __DIR__ . '/../images/' . $folder . '/';

    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0755, true);
    }

    if (preg_match('/^data:image\/(jpeg|png|webp);base64,(.+)$/i', $dataUri, $matches)) {
        $ext = '.' . ($matches[1] === 'jpeg' ? 'jpg' : $matches[1]);
        $binaryData = base64_decode($matches[2]);

        if ($binaryData === false) {
            http_response_code(400);
            echo json_encode(['error' => 'Cadena Base64 corrupta']);
            exit;
        }

        $filename = 'foto-slot-' . round(microtime(true) * 1000) . '-' . mt_rand(100, 999) . $ext;
        $destination = $targetDir . $filename;

        if (file_put_contents($destination, $binaryData) !== false) {
            chmod($destination, 0644);
            echo json_encode([
                'success' => true,
                'url'     => 'images/' . $folder . '/' . $filename,
                'message' => 'Imagen base64 convertida y guardada en disco'
            ]);
            exit;
        }
    }
}
            chmod($destination, 0644);
            echo json_encode([
                'success' => true,
                'url'     => 'images/products/' . $filename,
                'message' => 'Imagen base64 convertida y guardada en disco'
            ]);
            exit;
        }
    }
}

http_response_code(400);
echo json_encode(['error' => 'No se recibió ningún archivo o imagen válida']);
