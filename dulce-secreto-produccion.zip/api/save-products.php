<?php
/**
 * ======================================================================
 * DULCE SECRETO — GUARDAR PRODUCTOS (MYSQL + PERSISTENCIA EN DISCO)
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$rawInput = file_get_contents('php://input');
$products = json_decode($rawInput, true);

if (!is_array($products)) {
    http_response_code(400);
    echo json_encode(['error' => 'Estructura de catálogo inválida']);
    exit;
}

require_once __DIR__ . '/db.php';
$pdo = getDatabaseConnection();
$savedInDb = false;

// 1. Guardar en Base de Datos MySQL si está disponible
if ($pdo !== null) {
    try {
        $pdo->beginTransaction();

        $sql = "INSERT INTO `productos` 
                (`id`, `name`, `category`, `regularPrice`, `salePrice`, `isFlashSale`, `rating`, `reviewsCount`, `salesCount`, `tags`, `description`, `composition`, `sizes`, `images`, `crossSellIds`)
                VALUES (:id, :name, :category, :regularPrice, :salePrice, :isFlashSale, :rating, :reviewsCount, :salesCount, :tags, :description, :composition, :sizes, :images, :crossSellIds)
                ON DUPLICATE KEY UPDATE 
                  `name` = VALUES(`name`),
                  `category` = VALUES(`category`),
                  `regularPrice` = VALUES(`regularPrice`),
                  `salePrice` = VALUES(`salePrice`),
                  `isFlashSale` = VALUES(`isFlashSale`),
                  `description` = VALUES(`description`),
                  `composition` = VALUES(`composition`),
                  `tags` = VALUES(`tags`),
                  `sizes` = VALUES(`sizes`),
                  `images` = VALUES(`images`),
                  `crossSellIds` = VALUES(`crossSellIds`)";

        $stmt = $pdo->prepare($sql);

        foreach ($products as $p) {
            $stmt->execute([
                ':id'           => $p['id'],
                ':name'         => $p['name'],
                ':category'     => $p['category'] ?? 'Lencería',
                ':regularPrice' => (int)($p['regularPrice'] ?? 0),
                ':salePrice'    => (int)($p['salePrice'] ?? 0),
                ':isFlashSale'  => !empty($p['isFlashSale']) ? 1 : 0,
                ':rating'       => (float)($p['rating'] ?? 4.9),
                ':reviewsCount' => (int)($p['reviewsCount'] ?? 100),
                ':salesCount'   => (int)($p['salesCount'] ?? 500),
                ':tags'         => json_encode($p['tags'] ?? [], JSON_UNESCAPED_UNICODE),
                ':description'  => $p['description'] ?? '',
                ':composition'  => $p['composition'] ?? '',
                ':sizes'        => json_encode($p['sizes'] ?? [], JSON_UNESCAPED_UNICODE),
                ':images'       => json_encode($p['images'] ?? [], JSON_UNESCAPED_UNICODE),
                ':crossSellIds' => json_encode($p['crossSellIds'] ?? [], JSON_UNESCAPED_UNICODE),
            ]);
        }

        $pdo->commit();
        $savedInDb = true;
    } catch (Exception $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('[DB Save Error] ' . $e->getMessage());
    }
}

// 2. Persistir SIEMPRE copia en el archivo store-products.json en disco
$jsonPath = __DIR__ . '/../store-products.json';
$diskSaved = file_put_contents($jsonPath, json_encode($products, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

echo json_encode([
    'success'   => true,
    'message'   => 'Catálogo guardado con éxito en el servidor',
    'count'     => count($products),
    'savedInDb' => $savedInDb,
    'diskSaved' => $diskSaved !== false
]);
