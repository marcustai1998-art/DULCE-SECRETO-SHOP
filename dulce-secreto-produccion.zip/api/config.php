<?php
/**
 * ======================================================================
 * DULCE SECRETO — CONFIGURACIÓN DE BASE DE DATOS MYSQL (HOSTINGER / cPANEL)
 * ======================================================================
 * Ingresa aquí las credenciales que creaste en hPanel > Bases de Datos MySQL
 */

// Si usas variables de entorno (.env) o configuración directa:
define('DB_HOST', getenv('DB_HOST') ?: 'localhost'); // En Hostinger normalmente es 'localhost'
define('DB_NAME', getenv('DB_NAME') ?: 'u123456789_dulcesecreto'); // Nombre de la BD en Hostinger
define('DB_USER', getenv('DB_USER') ?: 'u123456789_admin'); // Usuario de la BD en Hostinger
define('DB_PASS', getenv('DB_PASS') ?: 'TuPasswordSeguro2026!'); // Contraseña creada en Hostinger
define('DB_CHARSET', 'utf8mb4');

// Correo autorizado del administrador
define('ADMIN_EMAIL', 'dulcesecreto1497@gmail.com');
