<?php
/**
 * ======================================================================
 * DULCE SECRETO — AUTENTICACIÓN ADMIN SEGURA EN BACKEND (PHP / HOSTINGER)
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

require_once __DIR__ . '/config.php';

$rawInput = file_get_contents('php://input');
$data = json_decode($rawInput, true);

$email = strtolower(trim($data['email'] ?? ''));
$pass = trim($data['password'] ?? '');

$authorizedEmail = defined('ADMIN_EMAIL') ? ADMIN_EMAIL : 'dulcesecreto1497@gmail.com';
$validPasswords = ['Kaiwen199898', 'dulcesecreto2026'];

if ($email === $authorizedEmail && in_array($pass, $validPasswords, true)) {
    // Iniciar sesión segura de PHP
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['admin_logged'] = true;
    $_SESSION['admin_email'] = $authorizedEmail;
    $_SESSION['login_time'] = time();

    echo json_encode([
        'success'  => true,
        'message'  => 'Acceso concedido. Bienvenido a Dulce Secreto.',
        'redirect' => 'admin.html',
        'email'    => $authorizedEmail
    ]);
} else {
    http_response_code(401);
    echo json_encode([
        'success' => false,
        'error'   => 'Credenciales incorrectas.'
    ]);
}
