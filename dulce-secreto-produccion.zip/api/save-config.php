<?php
/**
 * ======================================================================
 * DULCE SECRETO — GUARDAR CONFIGURACIÓN Y BANNERS EN DISCO
 * ======================================================================
 */

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Método no permitido']);
    exit;
}

$rawInput = file_get_contents('php://input');
$config = json_decode($rawInput, true);

if (!is_array($config)) {
    http_response_code(400);
    echo json_encode(['error' => 'Formato de configuración inválido']);
    exit;
}

$configPath = __DIR__ . '/../store-config.json';
$saved = file_put_contents($configPath, json_encode($config, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));

if ($saved !== false) {
    echo json_encode([
        'success' => true,
        'message' => 'Configuración actualizada con éxito en el servidor'
    ]);
} else {
    http_response_code(500);
    echo json_encode(['error' => 'Error al escribir en store-config.json']);
}
