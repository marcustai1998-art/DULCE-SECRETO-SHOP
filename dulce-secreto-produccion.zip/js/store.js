// ==========================================================================
// DULCE SECRETO - MOTOR DE ESTADO Y SINCRONIZACIÓN EN TIEMPO REAL
// Manejo de Catálogo, Configuración General, Carrito, Pedidos y Broadcast
// ==========================================================================

const STORAGE_KEYS = {
  PRODUCTS: "dulce_secreto_products_v3",
  DELETED_PRODUCTS: "dulce_secreto_deleted_products_v1",
  CONFIG: "dulce_secreto_config_v1",
  CART: "dulce_secreto_cart_v1",
  ORDERS: "dulce_secreto_orders_v1",
  THEME: "dulce_secreto_theme",
  DARK_MODE: "dulce_secreto_dark_mode",
  ADMIN_SESSION: "dulce_secreto_admin_auth"
};

// IDs de prendas legacy o de prueba que jamás deben reaparecer
const BANNED_LEGACY_IDS = new Set([
  'ds-001', 'ds-002', 'ds-003', 'ds-004', 'ds-005', 'ds-006',
  'ds-007', 'ds-008', 'ds-009', 'ds-010', 'ds-011', 'ds-012',
  'ds-013', 'ds-014', 'ds-015'
]);

function isCleanProduct(prod) {
  if (!prod || !prod.id) return false;
  if (BANNED_LEGACY_IDS.has(prod.id)) return false;
  const allImgs = [...(prod.images || []), prod.image || ''].filter(Boolean);
  if (allImgs.some(img => typeof img === 'string' && img.includes('unsplash'))) return false;
  return true;
}

// ==========================================================================
// ALMACENAMIENTO ILIMITADO CLIENTE: INDEXEDDB (DulceSecretoDB)
// Expande la capacidad del navegador de 5MB a Gigabytes (Almacenamiento Ilimitado)
// ==========================================================================
class DulceSecretoDBManager {
  constructor() {
    this.dbName = 'DulceSecretoUnlimitedDB';
    this.storeName = 'unlimited_store';
    this.db = null;
    this.ready = this.init();
  }

  async init() {
    if (typeof indexedDB === 'undefined') return null;
    return new Promise((resolve) => {
      try {
        const req = indexedDB.open(this.dbName, 1);
        req.onupgradeneeded = (e) => {
          const db = e.target.result;
          if (!db.objectStoreNames.contains(this.storeName)) {
            db.createObjectStore(this.storeName);
          }
        };
        req.onsuccess = (e) => {
          this.db = e.target.result;
          resolve(this.db);
        };
        req.onerror = () => resolve(null);
      } catch (err) {
        resolve(null);
      }
    });
  }

  async set(key, val) {
    await this.ready;
    if (!this.db) return false;
    return new Promise((resolve) => {
      try {
        const tx = this.db.transaction([this.storeName], 'readwrite');
        const store = tx.objectStore(this.storeName);
        store.put(val, key);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch (e) {
        resolve(false);
      }
    });
  }

  async get(key) {
    await this.ready;
    if (!this.db) return null;
    return new Promise((resolve) => {
      try {
        const tx = this.db.transaction([this.storeName], 'readonly');
        const store = tx.objectStore(this.storeName);
        const req = store.get(key);
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => resolve(null);
      } catch (e) {
        resolve(null);
      }
    });
  }

  async delete(key) {
    await this.ready;
    if (!this.db) return false;
    return new Promise((resolve) => {
      try {
        const tx = this.db.transaction([this.storeName], 'readwrite');
        const store = tx.objectStore(this.storeName);
        store.delete(key);
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => resolve(false);
      } catch (e) {
        resolve(false);
      }
    });
  }
}
const dulceDB = new DulceSecretoDBManager();
window.dulceDB = dulceDB;

function safeSetItem(key, val) {
  try {
    localStorage.setItem(key, val);
    if (key === STORAGE_KEYS.PRODUCTS) {
      localStorage.setItem('dulce_secreto_products', val);
    }
  } catch (err) {
    console.warn(`[Dulce Secreto] Quota localStorage prevenida para ${key}. Datos preservados en IndexedDB y servidor.`);
  }
  dulceDB.set(key, val).catch(() => {});
}

// Canal de comunicación en tiempo real entre pestañas (Admin <-> Tienda)
let syncChannel = null;
try {
  if (typeof BroadcastChannel !== 'undefined') {
    syncChannel = new BroadcastChannel('dulce_secreto_realtime_sync');
  }
} catch (e) {
  console.warn("BroadcastChannel no soportado, usando Storage fallback");
}

// Función auxiliar de clonación y fusión profunda
function deepMerge(target, source) {
  const output = Object.assign({}, target);
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) {
          Object.assign(output, { [key]: source[key] });
        } else {
          output[key] = deepMerge(target[key], source[key]);
        }
      } else {
        Object.assign(output, { [key]: source[key] });
      }
    });
  }
  return output;
}

function isObject(item) {
  return (item && typeof item === 'object' && !Array.isArray(item));
}

class StoreService {
  constructor() {
    this.subscribers = [];
    this.cartSubscribers = [];
    this.configSubscribers = [];
    this.initProducts();
    this.initConfig();
    this.setupListeners();
    this.syncProductsWithServer();
    this.syncConfigWithServer();
    if (typeof solicitarAlmacenamientoPersistente === 'function') {
      solicitarAlmacenamientoPersistente().catch(() => {});
    }
  }

  // --------------------------------------------------------------------------
  // PRODUCTOS Y CATÁLOGO
  // --------------------------------------------------------------------------
  initProducts() {
    const saved = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
    if (!saved) {
      const cleanInitial = INITIAL_PRODUCTS.filter(isCleanProduct);
      safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(cleanInitial));
    } else {
      try {
        let current = JSON.parse(saved);
        if (!Array.isArray(current)) current = [];
        
        // Purgar inmediatamente cualquier prenda con fotos obsoletas o IDs legacy
        const initialLen = current.length;
        current = current.filter(isCleanProduct);
        let updated = (current.length !== initialLen);

        let deletedIds = [];
        try {
          deletedIds = JSON.parse(localStorage.getItem(STORAGE_KEYS.DELETED_PRODUCTS) || "[]");
        } catch (e) {}

        INITIAL_PRODUCTS.forEach(p => {
          if (!isCleanProduct(p)) return;
          if (Array.isArray(deletedIds) && deletedIds.includes(p.id)) return; // No reincorporar prendas eliminadas por el administrador
          const existing = current.find(c => c.id === p.id);
          if (!existing) {
            current.push(p);
            updated = true;
          } else {
            // Sincronizar nuevas tallas agregadas (como XXL) si no existen aún en la prenda
            if (Array.isArray(p.sizes) && Array.isArray(existing.sizes)) {
              p.sizes.forEach(sz => {
                const baseSize = sz.split(' ')[0];
                const hasSize = existing.sizes.some(s => s === sz || s.split(' ')[0] === baseSize);
                if (!hasSize) {
                  existing.sizes.push(sz);
                  updated = true;
                }
              });
            }
          }
        });
        // Eliminar campo de colores de cualquier prenda en almacenamiento local
        current.forEach(prod => {
          if (prod && prod.colors) {
            delete prod.colors;
            updated = true;
          }
        });
        if (updated || current.length === 0) {
          const finalClean = current.length > 0 ? current : INITIAL_PRODUCTS.filter(isCleanProduct);
          safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(finalClean));
        }
      } catch (e) {
        safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS.filter(isCleanProduct)));
      }
    }
  }

  getProducts() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PRODUCTS);
      if (data) {
        const parsed = JSON.parse(data);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const cleanParsed = parsed.filter(isCleanProduct);
          cleanParsed.forEach(p => { if (p && p.colors) delete p.colors; });
          this._cachedProducts = cleanParsed;
          return cleanParsed;
        }
      }
    } catch (e) {}
    if (Array.isArray(this._cachedProducts) && this._cachedProducts.length > 0) {
      return this._cachedProducts.filter(isCleanProduct);
    }
    return INITIAL_PRODUCTS.filter(isCleanProduct);
  }

  async syncProductsWithServer() {
    try {
      if (typeof fetch === 'function') {
        const isFile = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:');
        const endpoint = isFile ? 'http://127.0.0.1:3000/api/get-products' : '/api/get-products';
        let resp = null;
        try {
          resp = await fetch(endpoint);
        } catch (netErr) {}

        // Si el endpoint dinámico no responde (por ejemplo en despliegues estáticos como Netlify o Vercel),
        // cargar directamente el archivo estático store-products.json con los precios fijos oficiales
        if ((!resp || !resp.ok) && !isFile) {
          try {
            resp = await fetch('store-products.json');
          } catch (e) {}
        }

        if (resp && resp.ok) {
          const serverProducts = await resp.json();
          if (Array.isArray(serverProducts) && serverProducts.length > 0) {
            const cleanServerProducts = serverProducts.filter(isCleanProduct);
            safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(cleanServerProducts));
            this.notifyProductsChanged({ fromServer: true });
            return;
          }
        }
      }
    } catch (e) {}

    // Si aún no existe archivo en el servidor, guardamos la base inicial en disco
    const current = this.getProducts();
    if (Array.isArray(current) && current.length > 0) {
      this.persistProductsToServer(current);
    }
  }

  async syncConfigWithServer() {
    try {
      if (typeof fetch === 'function') {
        const isFile = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:');
        const endpoint = isFile ? 'http://127.0.0.1:3000/api/get-config' : '/api/get-config';
        let resp = null;
        try {
          resp = await fetch(endpoint);
        } catch (netErr) {}

        // Si el endpoint dinámico no responde (despliegues estáticos en Hostinger, Netlify, Vercel),
        // cargar directamente el archivo estático store-config.json con la configuración guardada
        if ((!resp || !resp.ok) && !isFile) {
          try {
            resp = await fetch('store-config.json');
          } catch (e) {}
        }

        if (resp && resp.ok) {
          const serverConfig = await resp.json();
          if (serverConfig && typeof serverConfig === 'object' && Object.keys(serverConfig).length > 0) {
            const current = this.getConfig();
            const merged = deepMerge(current, serverConfig);
            safeSetItem(STORAGE_KEYS.CONFIG, JSON.stringify(merged));
            this.notifyConfigSubscribers();
            return merged;
          }
        }
      }
    } catch (e) {}
  }

  async persistProductsToServer(products) {
    try {
      if (typeof fetch === 'function' && Array.isArray(products)) {
        const isFile = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:');
        const endpoint = isFile ? 'http://127.0.0.1:3000/api/save-products' : '/api/save-products';
        await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(products)
        });
      }
    } catch (e) {}
  }

  saveAllProducts(products) {
    if (Array.isArray(products)) {
      safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
      this.persistProductsToServer(products);
      this.notifyProductsChanged({ allSaved: true });
    }
  }

  getProductById(id) {
    const list = this.getProducts();
    return list.find(p => p.id === id) || null;
  }

  updateProduct(id, updatedFields) {
    const products = this.getProducts();
    const index = products.findIndex(p => p.id === id);
    if (index !== -1) {
      products[index] = { ...products[index], ...updatedFields };
      safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
      this.persistProductsToServer(products);
      this.notifyProductsChanged(products[index]);
      return products[index];
    }
    return null;
  }

  addProduct(newProduct) {
    const products = this.getProducts();
    const product = {
      id: "ds-" + Date.now().toString(36),
      rating: 5.0,
      reviewsCount: 1,
      salesCount: 1,
      ...newProduct
    };
    products.unshift(product);
    safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));
    this.persistProductsToServer(products);
    this.notifyProductsChanged(product);
    return product;
  }

  deleteProduct(id) {
    let products = this.getProducts();
    products = products.filter(p => p.id !== id);
    safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));

    try {
      const deletedIds = JSON.parse(localStorage.getItem(STORAGE_KEYS.DELETED_PRODUCTS) || "[]");
      if (!deletedIds.includes(id)) {
        deletedIds.push(id);
        safeSetItem(STORAGE_KEYS.DELETED_PRODUCTS, JSON.stringify(deletedIds));
      }
    } catch (e) {}

    this.persistProductsToServer(products);
    this.notifyProductsChanged({ deletedId: id });
  }

  deleteMultipleProducts(ids) {
    if (!Array.isArray(ids) || ids.length === 0) return;
    const idSet = new Set(ids);
    let products = this.getProducts();
    products = products.filter(p => !idSet.has(p.id));
    safeSetItem(STORAGE_KEYS.PRODUCTS, JSON.stringify(products));

    try {
      const deletedIds = JSON.parse(localStorage.getItem(STORAGE_KEYS.DELETED_PRODUCTS) || "[]");
      ids.forEach(id => {
        if (!deletedIds.includes(id)) deletedIds.push(id);
      });
      safeSetItem(STORAGE_KEYS.DELETED_PRODUCTS, JSON.stringify(deletedIds));
    } catch (e) {}

    this.persistProductsToServer(products);
    this.notifyProductsChanged({ deletedIds: ids });
  }

  notifyProductsChanged(payload) {
    if (syncChannel) {
      syncChannel.postMessage({ type: 'PRODUCTS_UPDATED', payload });
    }
    this.notifySubscribers();
  }

  subscribeProducts(callback) {
    this.subscribers.push(callback);
    return () => {
      this.subscribers = this.subscribers.filter(cb => cb !== callback);
    };
  }

  notifySubscribers() {
    const products = this.getProducts();
    this.subscribers.forEach(cb => {
      try { cb(products); } catch (err) { console.error(err); }
    });
  }

  // --------------------------------------------------------------------------
  // CONFIGURACIÓN MAESTRA DE LA TIENDA (ADMIN EXCLUSIVO)
  // --------------------------------------------------------------------------
  initConfig() {
    const saved = localStorage.getItem(STORAGE_KEYS.CONFIG);
    if (!saved) {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(STORE_CONFIG));
    } else {
      try {
        const parsed = JSON.parse(saved);
        if (parsed && parsed.hero && Array.isArray(parsed.hero.images)) {
          const filtered = parsed.hero.images.filter(img => !img.includes('banner-vino-secreto'));
          if (filtered.length !== parsed.hero.images.length) {
            parsed.hero.images = filtered;
            if (parsed.hero.imageUrl && parsed.hero.imageUrl.includes('banner-vino-secreto')) {
              parsed.hero.imageUrl = filtered[0] || 'images/banners/banner-01-dulce-secreto-seduccion.jpg';
            }
            localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(parsed));
          }
        }
      } catch (e) {}
    }
    try {
      const cfg = this.getConfig();
      const phone = (cfg && cfg.customerService && cfg.customerService.agent1Wa) ? cfg.customerService.agent1Wa : '573132393554';
      localStorage.setItem('whatsapp_dulce', phone);
      localStorage.removeItem('whatsapp_sandra');
    } catch (e) {}
  }

  getConfig() {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.CONFIG);
      let cfg = STORE_CONFIG;
      if (data) {
        const parsed = JSON.parse(data);
        cfg = deepMerge(STORE_CONFIG, parsed);
      }
      if (cfg && cfg.hero) {
        if (Array.isArray(cfg.hero.images)) {
          cfg.hero.images = cfg.hero.images.filter(img => !img.includes('banner-vino-secreto'));
        }
        if (cfg.hero.imageUrl && cfg.hero.imageUrl.includes('banner-vino-secreto')) {
          cfg.hero.imageUrl = cfg.hero.images?.[0] || 'images/banners/banner-01-dulce-secreto-seduccion.jpg';
        }
      }
      return cfg;
    } catch (e) {
      return STORE_CONFIG;
    }
  }

  updateConfig(newConfigPartial) {
    const current = this.getConfig();
    const merged = deepMerge(current, newConfigPartial);
    
    try {
      localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(merged));
      if (merged && merged.customerService && merged.customerService.agent1Wa) {
        localStorage.setItem('whatsapp_dulce', String(merged.customerService.agent1Wa).replace(/\D/g, ''));
        localStorage.removeItem('whatsapp_sandra');
      }
    } catch (quotaErr) {
      console.warn("⚠️ Advertencia de cuota en localStorage:", quotaErr);
      try {
        localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(merged));
      } catch (finalErr) {
        console.error("❌ Error guardando en localStorage:", finalErr);
      }
    }

    // Respaldo automático en disco en servidor dulce-secreto (si está activo)
    try {
      const isFile = (typeof window !== 'undefined' && window.location && window.location.protocol === 'file:');
      const saveEndpoint = isFile ? 'http://127.0.0.1:3000/api/save-config' : '/api/save-config';
      fetch(saveEndpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(merged)
      }).catch(() => {});
    } catch (e) {}
    
    // Notifica por canal Broadcast y suscriptores locales
    if (syncChannel) {
      try {
        syncChannel.postMessage({ type: 'CONFIG_UPDATED', payload: merged });
      } catch (e) {
        console.warn("Error enviando BroadcastChannel:", e);
      }
    }
    this.notifyConfigSubscribers();
    return merged;
  }

  resetConfig() {
    localStorage.setItem(STORAGE_KEYS.CONFIG, JSON.stringify(STORE_CONFIG));
    if (syncChannel) {
      syncChannel.postMessage({ type: 'CONFIG_UPDATED', payload: STORE_CONFIG });
    }
    this.notifyConfigSubscribers();
    return STORE_CONFIG;
  }

  subscribeConfig(callback) {
    this.configSubscribers.push(callback);
    return () => {
      this.configSubscribers = this.configSubscribers.filter(cb => cb !== callback);
    };
  }

  notifyConfigSubscribers() {
    const config = this.getConfig();
    this.configSubscribers.forEach(cb => {
      try { cb(config); } catch (err) { console.error(err); }
    });
  }

  // --------------------------------------------------------------------------
  // LISTENERS EN VIVO Y BROADCAST
  // --------------------------------------------------------------------------
  setupListeners() {
    if (syncChannel) {
      syncChannel.onmessage = (event) => {
        if (event.data) {
          if (event.data.type === 'PRODUCTS_UPDATED') {
            console.log("⚡ Cambio de producto en tiempo real:", event.data.payload);
            this.notifySubscribers();
          } else if (event.data.type === 'CONFIG_UPDATED') {
            console.log("⚡ Cambio de configuración en tiempo real:", event.data.payload);
            this.notifyConfigSubscribers();
          }
        }
      };
    }

    // Canal BroadcastChannel adicional solicitado para sincronización de catálogo
    try {
      if (typeof BroadcastChannel !== 'undefined') {
        const canalSync = new BroadcastChannel('dulce_secreto_sync');
        canalSync.onmessage = (event) => {
          if (event && event.data && event.data.tipo === 'ACTUALIZAR_CATALOGO') {
            console.log("⚡ Catálogo sincronizado vía BroadcastChannel('dulce_secreto_sync'):", event.data.productos);
            this.notifySubscribers();
          }
        };
      }
    } catch (e) {}

    window.addEventListener('storage', (e) => {
      if (e.key === STORAGE_KEYS.PRODUCTS) {
        this.notifySubscribers();
      }
      if (e.key === STORAGE_KEYS.CONFIG) {
        this.notifyConfigSubscribers();
      }
      if (e.key === STORAGE_KEYS.CART) {
        this.notifyCartSubscribers();
      }
    });
  }

  // --------------------------------------------------------------------------
  // CARRITO DE COMPRAS
  // --------------------------------------------------------------------------
  getCart() {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.CART) || localStorage.getItem('dulce_secreto_cart');
      if (!saved) return [];
      const parsed = JSON.parse(saved);
      if (!Array.isArray(parsed)) return [];
      return parsed
        .filter(item => !BANNED_LEGACY_IDS.has(item.productId) && !BANNED_LEGACY_IDS.has(item.id))
        .map(item => ({
        ...item,
        name: item.name || item.nombre,
        nombre: item.nombre || item.name,
        price: item.price !== undefined ? item.price : (item.precio !== undefined ? item.precio : 0),
        precio: item.precio !== undefined ? item.precio : (item.price !== undefined ? item.price : 0),
        size: item.size || item.talla || 'Única',
        talla: item.talla || item.size || 'Única',
        quantity: item.quantity !== undefined ? item.quantity : (item.cantidad !== undefined ? item.cantidad : 1),
        cantidad: item.cantidad !== undefined ? item.cantidad : (item.quantity !== undefined ? item.quantity : 1)
      }));
    } catch (e) {
      return [];
    }
  }

  saveCart(cart) {
    if (!Array.isArray(cart)) cart = [];
    const normalizedCart = cart.map(item => ({
      ...item,
      name: item.name || item.nombre,
      nombre: item.nombre || item.name,
      price: item.price !== undefined ? item.price : (item.precio !== undefined ? item.precio : 0),
      precio: item.precio !== undefined ? item.precio : (item.price !== undefined ? item.price : 0),
      size: item.size || item.talla || 'Única',
      talla: item.talla || item.size || 'Única',
      quantity: item.quantity !== undefined ? item.quantity : (item.cantidad !== undefined ? item.cantidad : 1),
      cantidad: item.cantidad !== undefined ? item.cantidad : (item.quantity !== undefined ? item.quantity : 1)
    }));

    localStorage.setItem(STORAGE_KEYS.CART, JSON.stringify(normalizedCart));
    try {
      localStorage.setItem('dulce_secreto_cart', JSON.stringify(normalizedCart));
    } catch (e) {}
    this.notifyCartSubscribers();
  }

  addToCart(productId, size, colorName, quantity = 1) {
    const product = this.getProductById(productId);
    if (!product) return;

    const cart = this.getCart();
    const existingIndex = cart.findIndex(item => 
      item.productId === productId && item.size === size
    );

    if (existingIndex > -1) {
      cart[existingIndex].quantity += quantity;
    } else {
      const image = (Array.isArray(product.images) && product.images.length > 0) ? product.images[0] : (product.image || 'images/products/default.jpg');
      
      cart.push({
        cartItemId: `${productId}_${size}_${Date.now()}`,
        productId,
        name: product.name,
        price: product.salePrice || product.regularPrice,
        regularPrice: product.regularPrice,
        size,
        colorName: "",
        image,
        quantity
      });
    }

    this.saveCart(cart);
  }

  updateCartItem(cartItemId, updates) {
    let cart = this.getCart();
    cart = cart.map(item => {
      if (item.cartItemId === cartItemId) {
        return { ...item, ...updates };
      }
      return item;
    });
    this.saveCart(cart);
  }

  removeFromCart(cartItemId) {
    let cart = this.getCart();
    cart = cart.filter(item => item.cartItemId !== cartItemId);
    this.saveCart(cart);
  }

  clearCart() {
    this.saveCart([]);
  }

  getCartTotals() {
    const cart = this.getCart();
    const config = this.getConfig();
    const stdShippingCost = config.shippingCost || 12000;

    const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const count = cart.reduce((acc, item) => acc + item.quantity, 0);
    const freeShipping = false;
    const shippingCost = count === 0 ? 0 : stdShippingCost;
    const total = subtotal + shippingCost;
    const freeShippingProgress = 0;
    const amountNeededForFreeShipping = 0;

    return {
      subtotal,
      shippingCost,
      total,
      count,
      freeShipping,
      freeShippingProgress,
      amountNeededForFreeShipping
    };
  }

  subscribeCart(callback) {
    this.cartSubscribers.push(callback);
    return () => {
      this.cartSubscribers = this.cartSubscribers.filter(cb => cb !== callback);
    };
  }

  notifyCartSubscribers() {
    const cart = this.getCart();
    const totals = this.getCartTotals();
    this.cartSubscribers.forEach(cb => {
      try { cb(cart, totals); } catch (err) { console.error(err); }
    });
  }

  // --------------------------------------------------------------------------
  // PEDIDOS (ORDERS)
  // --------------------------------------------------------------------------
  saveOrder(orderData) {
    try {
      const orders = this.getOrders();
      const newOrder = {
        id: "DS-" + Math.floor(100000 + Math.random() * 900000),
        date: new Date().toISOString(),
        status: "Pendiente de Verificación",
        ...orderData
      };
      orders.unshift(newOrder);
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
      return newOrder;
    } catch (e) {
      console.error("Error guardando orden:", e);
      return null;
    }
  }

  getOrders() {
    try {
      const saved = localStorage.getItem(STORAGE_KEYS.ORDERS);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  }

  updateOrderStatus(orderId, status) {
    const orders = this.getOrders();
    const order = orders.find(o => o.id === orderId);
    if (order) {
      order.status = status;
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    }
  }

  deleteOrderVoucher(orderId) {
    const orders = this.getOrders();
    const order = orders.find(o => o.id === orderId);
    if (order) {
      order.voucher = null;
      order.voucherUrl = null;
      order.hasVoucher = false;
      order.voucherSnippet = null;
      localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
      return true;
    }
    return false;
  }

  deleteOrder(orderId) {
    let orders = this.getOrders();
    orders = orders.filter(o => o.id !== orderId);
    localStorage.setItem(STORAGE_KEYS.ORDERS, JSON.stringify(orders));
    return true;
  }
}

// Formateador de moneda colombiana (COP)
function formatCOP(amount) {
  return new Intl.NumberFormat('es-CO', {
    style: 'currency',
    currency: 'COP',
    maximumFractionDigits: 0
  }).format(amount);
}

// Instancia global del servicio
const store = new StoreService();
window.store = store;
window.formatCOP = formatCOP;
window.STORE_CONFIG = STORE_CONFIG;

// ==========================================================================
// SEGURIDAD & AUTENTICACIÓN ADMINISTRATIVA (CORREO, CLAVE Y CÓDIGOS)
// ==========================================================================
const DEFAULT_ADMIN_EMAIL = "dulcesecreto1497@gmail.com";
const DEFAULT_ADMIN_PASSWORD = "Kaiwen199898";
const STORAGE_KEY_ADMIN_EMAIL = "dulce_secreto_admin_email";
const STORAGE_KEY_ADMIN_PASS = "dulce_secreto_admin_password";
const STORAGE_KEY_ADMIN_SESSION = "dulce_secreto_admin_logged";

function getAdminEmail() {
  return (localStorage.getItem(STORAGE_KEY_ADMIN_EMAIL) || DEFAULT_ADMIN_EMAIL).toLowerCase().trim();
}

function setAdminEmail(newEmail) {
  const clean = newEmail.toLowerCase().trim();
  localStorage.setItem(STORAGE_KEY_ADMIN_EMAIL, clean);
  if (syncChannel) {
    try { syncChannel.postMessage({ type: 'ADMIN_EMAIL_CHANGED', email: clean }); } catch (e) {}
  }
}

function getAdminPassword() {
  return localStorage.getItem(STORAGE_KEY_ADMIN_PASS) || DEFAULT_ADMIN_PASSWORD;
}

function setAdminPassword(newPass) {
  localStorage.setItem(STORAGE_KEY_ADMIN_PASS, newPass);
}

function generateVerificationCode() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

async function sendVerificationCodeToEmail(targetEmail, purpose = "login") {
  const code = generateVerificationCode();
  const sessionData = {
    email: targetEmail.toLowerCase().trim(),
    code: code,
    purpose: purpose,
    timestamp: Date.now(),
    expiresAt: Date.now() + (10 * 60 * 1000) // 10 minutos de validez
  };

  sessionStorage.setItem("dulce_secreto_temp_code_" + purpose, JSON.stringify(sessionData));

  // Notificar al backend local
  try {
    fetch('/api/send-code', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: targetEmail, code: code, type: purpose })
    }).catch(() => {});
  } catch (e) {}

  return { success: true, code, email: targetEmail, expiresAt: sessionData.expiresAt };
}

function verifyEmailCode(inputCode, purpose = "login") {
  try {
    const raw = sessionStorage.getItem("dulce_secreto_temp_code_" + purpose);
    if (!raw) return { valid: false, reason: "No se ha solicitado ningún código aún. Haz clic en 'Enviar Código'." };
    const data = JSON.parse(raw);
    if (Date.now() > data.expiresAt) {
      return { valid: false, reason: "El código de verificación ha expirado. Por favor solicita uno nuevo." };
    }
    if (data.code !== inputCode.toString().trim()) {
      return { valid: false, reason: "El código de verificación ingresado es incorrecto." };
    }
    return { valid: true, data };
  } catch (e) {
    return { valid: false, reason: "Error al validar el código." };
  }
}

window.getAdminEmail = getAdminEmail;
window.setAdminEmail = setAdminEmail;
window.getAdminPassword = getAdminPassword;
window.setAdminPassword = setAdminPassword;
window.generateVerificationCode = generateVerificationCode;
window.sendVerificationCodeToEmail = sendVerificationCodeToEmail;
window.verifyEmailCode = verifyEmailCode;

// Exportar toda la configuración y productos actuales a un archivo JSON
function exportarRespaldoTienda() {
    const prods = (window.store && typeof window.store.getProducts === 'function') 
        ? window.store.getProducts() 
        : (JSON.parse(localStorage.getItem('dulce_secreto_products')) || JSON.parse(localStorage.getItem('dulce_secreto_products_v2')) || []);
    
    const config = (window.store && typeof window.store.getConfig === 'function')
        ? window.store.getConfig()
        : (JSON.parse(localStorage.getItem('dulce_secreto_config')) || JSON.parse(localStorage.getItem('dulce_secreto_config_v1')) || {});

    const banners = (config && config.hero && Array.isArray(config.hero.images))
        ? config.hero.images
        : (JSON.parse(localStorage.getItem('dulce_secreto_banners')) || []);

    const estadoTienda = {
        productos: prods,
        config: config,
        banners: banners,
        fechaRespaldo: new Date().toISOString()
    };
    
    try {
        localStorage.setItem('dulce_secreto_products', JSON.stringify(prods));
        localStorage.setItem('dulce_secreto_config', JSON.stringify(config));
        localStorage.setItem('dulce_secreto_banners', JSON.stringify(banners));
    } catch (e) {}

    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(estadoTienda, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute("href", dataStr);
    downloadAnchor.setAttribute("download", `respaldo_dulce_secreto_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
}

// Importar respaldo desde un archivo JSON
function importarRespaldoTienda(event) {
    const archivo = event.target.files && event.target.files[0];
    if (!archivo) return;
    
    const reader = new FileReader();
    reader.onload = function(e) {
        try {
            const contenido = JSON.parse(e.target.result);
            if (contenido.productos) {
                localStorage.setItem('dulce_secreto_products', JSON.stringify(contenido.productos));
                localStorage.setItem('dulce_secreto_products_v2', JSON.stringify(contenido.productos));
                if (window.store && typeof window.store.saveAllProducts === 'function') {
                    window.store.saveAllProducts(contenido.productos);
                }
            }
            if (contenido.config) {
                localStorage.setItem('dulce_secreto_config', JSON.stringify(contenido.config));
                localStorage.setItem('dulce_secreto_config_v1', JSON.stringify(contenido.config));
                if (window.store && typeof window.store.updateConfig === 'function') {
                    window.store.updateConfig(contenido.config);
                }
            }
            if (contenido.banners) {
                localStorage.setItem('dulce_secreto_banners', JSON.stringify(contenido.banners));
            }
            
            alert("✅ ¡Respaldo restaurado con éxito! La tienda se actualizará ahora.");
            window.location.reload();
        } catch (error) {
            alert("❌ Error al leer el archivo de respaldo. Asegúrate de que sea un JSON válido.");
        }
    };
    reader.readAsText(archivo);
}

function comprimirYConvertirImagen(file, callback) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
        let rawData = e.target.result;
        if (typeof rawData === 'string' && (rawData.startsWith('data:application/octet-stream;base64,') || rawData.startsWith('data:;base64,'))) {
            const b64 = rawData.split(',')[1] || '';
            if (b64.startsWith('/9j/')) rawData = 'data:image/jpeg;base64,' + b64;
            else if (b64.startsWith('iVBORw0KGgo')) rawData = 'data:image/png;base64,' + b64;
            else if (b64.startsWith('UklGR')) rawData = 'data:image/webp;base64,' + b64;
            else rawData = 'data:image/jpeg;base64,' + b64;
        }

        const img = new Image();
        img.onload = function () {
            try {
                const canvas = document.createElement('canvas');
                let width = img.naturalWidth || img.width;
                let height = img.naturalHeight || img.height;
                
                const MAX_WIDTH = 800;
                const MAX_HEIGHT = 800;
                
                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height = Math.round(height * (MAX_WIDTH / width));
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width = Math.round(width * (MAX_HEIGHT / height));
                        height = MAX_HEIGHT;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
                callback(dataUrl);
            } catch (err) {
                callback(rawData);
            }
        };
        img.onerror = function () {
            callback(rawData);
        };
        img.src = rawData;
    };
    reader.readAsDataURL(file);
}

function mostrarToastAdmin(mensaje) {
    let container = document.getElementById('dulceToastContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'dulceToastContainer';
        document.body.appendChild(container);
    }
    
    const toast = document.createElement('div');
    toast.className = 'dulce-toast';
    toast.innerHTML = `✨ ${mensaje}`;
    
    container.appendChild(toast);
    
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function guardarNuevaPrenda(nuevaPrenda) {
    // 1. Obtener productos actuales o iniciar array vacío
    let productos = [];
    try {
        productos = JSON.parse(localStorage.getItem('dulce_secreto_products')) || [];
    } catch (e) {
        productos = [];
    }
    if ((!productos || productos.length === 0) && window.store && typeof window.store.getProducts === 'function') {
        productos = window.store.getProducts() || [];
    }
    
    // 2. Asignar un ID único basado en el tiempo si no lo tiene
    nuevaPrenda.id = nuevaPrenda.id || 'prenda_' + Date.now();
    nuevaPrenda.name = nuevaPrenda.name || nuevaPrenda.nombre || "Nueva Prenda";
    nuevaPrenda.nombre = nuevaPrenda.nombre || nuevaPrenda.name;
    nuevaPrenda.regularPrice = Number(nuevaPrenda.regularPrice || nuevaPrenda.precio || 0);
    nuevaPrenda.salePrice = Number(nuevaPrenda.salePrice || nuevaPrenda.precio || nuevaPrenda.regularPrice || 0);
    nuevaPrenda.price = nuevaPrenda.salePrice || nuevaPrenda.regularPrice;
    nuevaPrenda.precio = nuevaPrenda.salePrice || nuevaPrenda.regularPrice;
    nuevaPrenda.images = nuevaPrenda.images || (nuevaPrenda.imagen ? [nuevaPrenda.imagen] : []);
    nuevaPrenda.category = nuevaPrenda.category || nuevaPrenda.categoria || "Babydoll";
    nuevaPrenda.description = nuevaPrenda.description || nuevaPrenda.descripcion || "Prenda exclusiva Dulce Secreto.";
    nuevaPrenda.sizes = nuevaPrenda.sizes || nuevaPrenda.tallas || ["S", "M", "L", "XL"];
    delete nuevaPrenda.colors;
    
    // 3. Agregar la nueva prenda al inicio del array
    productos.unshift(nuevaPrenda);
    
    try {
        // 4. Guardar en localStorage de forma segura
        localStorage.setItem('dulce_secreto_products', JSON.stringify(productos));
        localStorage.setItem('dulce_secreto_products_v2', JSON.stringify(productos));
        
        // Sincronizar en disco con el servidor y notificar al Store
        if (window.store && typeof window.store.persistProductsToServer === 'function') {
            window.store.persistProductsToServer(productos);
        }
        if (window.store && typeof window.store.notifyProductsChanged === 'function') {
            window.store.notifyProductsChanged(nuevaPrenda);
        }
        
        // 5. Notificar a todas las pestañas abiertas (admin y tienda) en tiempo real
        if (typeof BroadcastChannel !== 'undefined') {
            try {
                const canal = new BroadcastChannel('dulce_secreto_sync');
                canal.postMessage({ tipo: 'ACTUALIZAR_CATALOGO', productos: productos });
                canal.postMessage({ tipo: 'ACTUALIZ_CATALOGO', productos: productos });
            } catch (e) {}
        }
        
        console.log("✅ Prenda guardada y sincronizada con éxito:", nuevaPrenda.nombre);
        return true;
    } catch (error) {
        console.error("❌ Error al guardar en localStorage (posible exceso de peso por imágenes muy grandes):", error);
        alert("⚠️ La imagen es demasiado pesada para la memoria del navegador. Por favor usa una imagen más ligera o comprimida.");
        return false;
    }
}

if (typeof console !== 'undefined' && !console.lu) {
    console.lu = console.log;
}

function renderizarCatalogoPrincipal(productos) {
    if (Array.isArray(productos) && productos.length > 0) {
        if (window.store && typeof window.store.saveAllProducts === 'function') {
            window.store.saveAllProducts(productos);
        } else {
            try {
                localStorage.setItem('dulce_secreto_products', JSON.stringify(productos));
                localStorage.setItem('dulce_secreto_products_v2', JSON.stringify(productos));
            } catch (e) {}
        }
    }
    if (typeof window.renderProductsGrid === 'function') {
        window.renderProductsGrid("", productos);
    }
}

async function solicitarAlmacenamientoPersistente() {
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.persist) {
        try {
            const persistente = await navigator.storage.persist();
            if (persistente) {
                console.log("✨ ¡El navegador ha concedido almacenamiento persistente para la tienda!");
            } else {
                console.log("⚠️ El navegador denegó el almacenamiento persistente automático.");
            }
        } catch (e) {
            console.warn("Aviso almacenamiento persistente:", e);
        }
    }
    
    // Consultar cuánto espacio tienes disponible actualmente
    if (typeof navigator !== 'undefined' && navigator.storage && navigator.storage.estimate) {
        try {
            const estimacion = await navigator.storage.estimate();
            const usadoMB = (estimacion.usage / (1024 * 1024)).toFixed(2);
            const totalMB = (estimacion.quota / (1024 * 1024)).toFixed(2);
            console.log(`📊 Espacio usado: ${usadoMB} MB de ${totalMB} MB disponibles.`);
        } catch (e) {}
    }
}

// Ejecutar al cargar la página
if (typeof window !== 'undefined') {
    window.addEventListener('DOMContentLoaded', solicitarAlmacenamientoPersistente);
    window.solicitarAlmacenamientoPersistente = solicitarAlmacenamientoPersistente;
}

window.renderizarCatalogoPrincipal = renderizarCatalogoPrincipal;
window.guardarNuevaPrenda = guardarNuevaPrenda;
window.mostrarToastAdmin = mostrarToastAdmin;
window.showAdminToast = mostrarToastAdmin;
window.comprimirYConvertirImagen = comprimirYConvertirImagen;
window.exportarRespaldoTienda = exportarRespaldoTienda;
window.importarRespaldoTienda = importarRespaldoTienda;
window.STORAGE_KEY_ADMIN_EMAIL = STORAGE_KEY_ADMIN_EMAIL;
window.STORAGE_KEY_ADMIN_PASS = STORAGE_KEY_ADMIN_PASS;
window.STORAGE_KEY_ADMIN_SESSION = STORAGE_KEY_ADMIN_SESSION;
