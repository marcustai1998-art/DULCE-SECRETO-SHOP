// ==========================================================================
// DULCE SECRETO - THEME SWITCHER DINÁMICO
// Selector de paletas en tiempo real (Rosa Dulce, Negro Secreto, Rojo Pasión, Nude)
// y conmutador Modo Claro / Modo Oscuro
// ==========================================================================

const THEMES = [
  {
    id: "rosa-dulce",
    name: "Rosa Dulce",
    subtitle: "Romántico & Coqueto",
    accentHex: "#e11d48",
    bgHex: "#fff5f7",
    badge: "Oficial"
  },
  {
    id: "negro-secreto",
    name: "Negro Secreto",
    subtitle: "Lujo, Misterio & Oro",
    accentHex: "#d97706",
    bgHex: "#121214",
    badge: "Premium"
  },
  {
    id: "rojo-pasion",
    name: "Rojo Pasión",
    subtitle: "Sensual & Provocativo",
    accentHex: "#dc2626",
    bgHex: "#fef2f2",
    badge: "Hot"
  },
  {
    id: "nude-pastel",
    name: "Nude Pastel",
    subtitle: "Elegante & Satín Champagne",
    accentHex: "#c27803",
    bgHex: "#faf7f2",
    badge: "Chic"
  },
  {
    id: "vino-secreto",
    name: "Vino Secreto",
    subtitle: "Catálogo 2026 · Borgoña & Satín",
    accentHex: "#9e1b32",
    bgHex: "#2b080f",
    badge: "Nuevo 2026"
  }
];

class ThemeManager {
  constructor() {
    this.currentTheme = localStorage.getItem("dulce_secreto_theme") || "vino-secreto";
    
    // Al abrir la página siempre se inicializa en MODO OSCURO por defecto
    const sessionLight = sessionStorage.getItem("dulce_secreto_user_toggled_light");
    if (sessionLight === "true") {
      this.isDarkMode = false;
    } else {
      this.isDarkMode = true;
      try {
        localStorage.setItem("dulce_secreto_dark_mode", "true");
      } catch (e) {}
    }

    this.applyTheme(this.currentTheme, this.isDarkMode);
  }

  setTheme(themeId) {
    if (!THEMES.some(t => t.id === themeId)) return;
    this.currentTheme = themeId;
    localStorage.setItem("dulce_secreto_theme", themeId);
    this.applyTheme(themeId, this.isDarkMode);
    this.updateUI();
  }

  toggleDarkMode() {
    this.isDarkMode = !this.isDarkMode;
    try {
      localStorage.setItem("dulce_secreto_dark_mode", this.isDarkMode ? "true" : "false");
      if (!this.isDarkMode) {
        sessionStorage.setItem("dulce_secreto_user_toggled_light", "true");
      } else {
        sessionStorage.removeItem("dulce_secreto_user_toggled_light");
      }
    } catch (e) {}
    this.applyTheme(this.currentTheme, this.isDarkMode);
    this.updateUI();
  }

  applyTheme(themeId, isDark) {
    const root = document.documentElement;
    root.setAttribute("data-theme", themeId);
    if (isDark) {
      root.classList.add("dark");
    } else {
      root.classList.remove("dark");
    }

    // Efecto interactivo especial para el tema Vino Secreto (Catálogo 2026)
    const scriptEl = document.getElementById("hero-title-script");
    const heroBgImg = document.getElementById("hero-bg-img");
    const ribbon2026 = document.getElementById("hero-ribbon-2026");

    if (themeId === "vino-secreto") {
      if (scriptEl) scriptEl.style.color = "#c23b53";
      if (heroBgImg) {
        const cfg = window.store ? window.store.getConfig() : null;
        heroBgImg.src = (cfg && cfg.hero && cfg.hero.imageUrl) || "images/banners/banner-01-dulce-secreto-seduccion.jpg";
      }
      if (ribbon2026) ribbon2026.classList.remove("hidden");
    } else {
      if (ribbon2026) ribbon2026.classList.remove("hidden");
      if (scriptEl && !window.customScriptColor) {
        if (themeId === "rosa-dulce") scriptEl.style.color = "#e11d48";
        else if (themeId === "negro-secreto") scriptEl.style.color = "#d97706";
        else if (themeId === "rojo-pasion") scriptEl.style.color = "#dc2626";
        else if (themeId === "nude-pastel") scriptEl.style.color = "#c27803";
      }
    }
  }

  updateUI() {
    // Actualiza botones de tema activos en el DOM
    document.querySelectorAll("[data-theme-btn]").forEach(btn => {
      const id = btn.getAttribute("data-theme-btn");
      if (id === this.currentTheme) {
        btn.classList.add("ring-2", "ring-offset-2", "ring-current", "scale-105");
      } else {
        btn.classList.remove("ring-2", "ring-offset-2", "ring-current", "scale-105");
      }
    });

    // Actualiza indicador de modo oscuro
    const darkToggleIcon = document.getElementById("dark-mode-icon");
    if (darkToggleIcon) {
      darkToggleIcon.innerHTML = this.isDarkMode 
        ? '<i data-lucide="sun" class="w-5 h-5 text-yellow-400"></i>'
        : '<i data-lucide="moon" class="w-5 h-5 text-gray-700"></i>';
      if (window.lucide) window.lucide.createIcons();
    }
  }
}

const themeManager = new ThemeManager();
window.themeManager = themeManager;
window.THEMES = THEMES;

document.addEventListener("DOMContentLoaded", () => {
  themeManager.updateUI();
});
