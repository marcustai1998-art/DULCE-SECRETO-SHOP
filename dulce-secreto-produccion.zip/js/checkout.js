// ==========================================================================
// DULCE SECRETO - PASARELA DE CHECKOUT HÍBRIDA & DESPACHO WHATSAPP
// Cobertura: 
// 1. Dentro de Bogotá D.C.: Pago Contra Entrega (Efectivo) o Nequi
// 2. Fuera de Bogotá (Nacional): Pago Anticipado (Nequi) + Flete según transportadora
// ==========================================================================

let selectedDeliveryZone = "bogota"; // "bogota" o "nacional"
let selectedPaymentMethod = "cod"; // "cod" o "transfer"
let selectedBank = "nequi";
let uploadedVoucherBase64 = null;

function setDeliveryZone(zone) {
  selectedDeliveryZone = zone;
  const btnBogota = document.getElementById("zone-btn-bogota");
  const btnNacional = document.getElementById("zone-btn-nacional");
  const policyText = document.getElementById("zone-policy-text");
  const tabCod = document.getElementById("tab-cod");
  const tabTransfer = document.getElementById("tab-transfer");
  const tabCodBadge = document.getElementById("tab-cod-badge");
  const tabTransferBadge = document.getElementById("tab-transfer-badge");
  const cityInput = document.getElementById("checkout-city");
  const deptInput = document.getElementById("checkout-department");

  const activeZoneClasses = ["border-[#9e1b32]", "bg-pink-50/70", "dark:bg-rose-950/40", "shadow-xs"];
  const inactiveZoneClasses = ["border-gray-200", "dark:border-neutral-700", "bg-white", "dark:bg-neutral-900"];

  if (zone === "bogota") {
    if (btnBogota) {
      btnBogota.classList.remove(...inactiveZoneClasses);
      btnBogota.classList.add(...activeZoneClasses);
    }
    if (btnNacional) {
      btnNacional.classList.remove(...activeZoneClasses);
      btnNacional.classList.add(...inactiveZoneClasses);
    }
    if (policyText) {
      policyText.innerHTML = `<strong>Entregas dentro de Bogotá D.C.:</strong> Tienes habilitado el <strong>Pago Contra Entrega</strong> (pagas en efectivo al mensajero al recibir) o transferencia Nequi directa.`;
    }
    if (tabCodBadge) tabCodBadge.classList.add("hidden");
    if (tabTransferBadge) tabTransferBadge.classList.add("hidden");
    if (tabCod) tabCod.classList.remove("opacity-50", "cursor-not-allowed");

    // Pre-llenar datos de Bogotá
    if (cityInput && (!cityInput.value || !cityInput.value.toLowerCase().includes("bogot"))) {
      cityInput.value = "Bogotá D.C.";
    }
    if (deptInput && (!deptInput.value || !deptInput.value.toLowerCase().includes("bogot"))) {
      deptInput.value = "Bogotá D.C.";
    }

    // Activar contra entrega como método preferido en Bogotá si no había elegido Nequi explícito
    if (selectedPaymentMethod !== "transfer") {
      selectPaymentMethod("cod");
    }
  } else {
    // Fuera de Bogotá (Nacional)
    if (btnNacional) {
      btnNacional.classList.remove(...inactiveZoneClasses);
      btnNacional.classList.add(...activeZoneClasses);
    }
    if (btnBogota) {
      btnBogota.classList.remove(...activeZoneClasses);
      btnBogota.classList.add(...inactiveZoneClasses);
    }
    if (policyText) {
      policyText.innerHTML = `<strong>Envíos Fuera de Bogotá:</strong> Se despachan con <strong>Pago Anticipado</strong> por Nequi. El precio del flete depende de la <strong>disponibilidad y tarifa de la empresa transportadora</strong> (Interrapidísimo / Servientrega / Envía).`;
    }
    if (tabCodBadge) tabCodBadge.classList.remove("hidden");
    if (tabTransferBadge) tabTransferBadge.classList.remove("hidden");
    if (tabCod) tabCod.classList.add("opacity-50");

    // Seleccionar obligatoriamente Transferencia (Pago Anticipado) para fuera de Bogotá
    selectPaymentMethod("transfer");

    // Si la ciudad era Bogotá, limpiar para que ingrese su municipio
    if (cityInput && cityInput.value.toLowerCase().includes("bogot")) {
      cityInput.value = "";
      cityInput.placeholder = "Ej: Cali, Medellín, Bucaramanga, Barranquilla...";
    }
    if (deptInput && deptInput.value.toLowerCase().includes("bogot")) {
      deptInput.value = "";
      deptInput.placeholder = "Ej: Valle del Cauca, Antioquia, Santander...";
    }
  }

  updateCheckoutSummary();
  if (window.lucide) window.lucide.createIcons();
}

function handleCityInput(val) {
  if (!val) return;
  const clean = val.trim().toLowerCase();
  if (clean.includes("bogot")) {
    if (selectedDeliveryZone !== "bogota") {
      setDeliveryZone("bogota");
    }
  } else if (clean.length >= 4 && !clean.includes("bogo")) {
    if (selectedDeliveryZone !== "nacional") {
      setDeliveryZone("nacional");
    }
  }
}

function openCheckoutModal(preferredMethod) {
  const totals = window.store.getCartTotals();
  if (totals.count === 0) {
    showToast("Tu carrito está vacío. Agrega prendas para continuar.");
    return;
  }
  // 1. Cierra el drawer de la bolsa lateral
  toggleCartDrawer(false);
  
  // 2. Cierra el modal de vista rápida si estuviera abierto
  const qModal = document.getElementById("quick-view-modal");
  if (qModal) qModal.classList.add("hidden");

  // 3. Abre directamente el modal de compra
  const modal = document.getElementById("checkout-modal");
  if (modal) {
    modal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    
    // Si viene de Bogotá o por defecto, aplica zona correspondiente
    setDeliveryZone(selectedDeliveryZone || "bogota");

    if (preferredMethod) {
      selectPaymentMethod(preferredMethod);
    }
    
    // Desplaza al inicio del formulario
    const form = modal.querySelector("form");
    if (form) form.scrollTop = 0;

    updateCheckoutSummary();
    if (window.lucide) window.lucide.createIcons();
  }
}

function closeCheckoutModal() {
  const modal = document.getElementById("checkout-modal");
  if (modal) {
    modal.classList.add("hidden");
    document.body.style.overflow = "";
  }
}

function selectPaymentMethod(method) {
  if (method === "cod" && selectedDeliveryZone === "nacional") {
    alert("⚠️ El Pago Contra Entrega está disponible únicamente dentro de Bogotá D.C.\n\nPara envíos fuera de Bogotá, los pedidos se despachan con Pago Anticipado por Nequi, y el precio del flete depende de la disponibilidad y tarifa de la empresa transportadora.");
    method = "transfer";
  }

  selectedPaymentMethod = method;
  const codTab = document.getElementById("tab-cod");
  const transferTab = document.getElementById("tab-transfer");
  const codDetails = document.getElementById("cod-details");
  const transferDetails = document.getElementById("transfer-details");

  const activeClasses = ["border-[#9e1b32]", "text-[#9e1b32]", "bg-pink-50/60", "dark:bg-neutral-800", "border-theme-primary", "text-theme-primary", "bg-theme-muted"];
  const inactiveClasses = ["border-transparent", "text-gray-500", "dark:text-neutral-400", "text-theme-muted"];

  if (method === "cod") {
    if (codTab) {
      codTab.classList.remove(...inactiveClasses);
      codTab.classList.add(...activeClasses);
    }
    if (transferTab) {
      transferTab.classList.remove(...activeClasses);
      transferTab.classList.add(...inactiveClasses);
    }

    codDetails?.classList.remove("hidden");
    transferDetails?.classList.add("hidden");
  } else {
    if (transferTab) {
      transferTab.classList.remove(...inactiveClasses);
      transferTab.classList.add(...activeClasses);
    }
    if (codTab) {
      codTab.classList.remove(...activeClasses);
      codTab.classList.add(...inactiveClasses);
    }

    transferDetails?.classList.remove("hidden");
    codDetails?.classList.add("hidden");
  }

  updateCheckoutSummary();
}

function selectBank(bankKey = "nequi") {
  selectedBank = "nequi";
  const btn = document.getElementById("bank-btn-nequi");
  const box = document.getElementById("bank-info-nequi");
  btn?.classList.add("border-theme-primary", "bg-theme-muted", "text-theme-primary", "font-bold");
  box?.classList.remove("hidden");
}

function copyToClipboard(text, elementId) {
  navigator.clipboard.writeText(text).then(() => {
    const btn = document.getElementById(elementId);
    if (btn) {
      const original = btn.innerHTML;
      btn.innerHTML = `<i data-lucide="check" class="w-4 h-4 text-emerald-500"></i> Copiado!`;
      if (window.lucide) window.lucide.createIcons();
      setTimeout(() => {
        btn.innerHTML = original;
        if (window.lucide) window.lucide.createIcons();
      }, 2000);
    }
    showToast("Número copiado al portapapeles");
  });
}

function comprimirYConvertirImagen(file, callback) {
    if (!file) return;
    const reader = new FileReader();
    reader.onload = function (e) {
        let rawData = e.target.result;
        // Normalización si viene de WhatsApp sin MIME estándar
        if (typeof rawData === 'string' && (rawData.startsWith('data:application/octet-stream;base64,') || rawData.startsWith('data:;base64,'))) {
            const b64 = rawData.split(',')[1] || '';
            if (b64.startsWith('/9j/')) rawData = 'data:image/jpeg;base64,' + b64;
            else if (b64.startsWith('iVBORw0KGgo')) rawData = 'data:image/png;base64,' + b64;
            else if (b64.startsWith('UklGR')) rawData = 'data:image/webp;base64,' + b64;
            else rawData = 'data:image/jpeg;base64,' + b64;
        }

        const img = new Image();
        img.onload = function () {
            try {
                const canvas = document.createElement('canvas');
                let width = img.naturalWidth || img.width;
                let height = img.naturalHeight || img.height;
                
                // Límite máximo de resolución para cuidar el almacenamiento local
                const MAX_WIDTH = 800;
                const MAX_HEIGHT = 800;
                
                if (width > height) {
                    if (width > MAX_WIDTH) {
                        height = Math.round(height * (MAX_WIDTH / width));
                        width = MAX_WIDTH;
                    }
                } else {
                    if (height > MAX_HEIGHT) {
                        width = Math.round(width * (MAX_HEIGHT / height));
                        height = MAX_HEIGHT;
                    }
                }
                
                canvas.width = width;
                canvas.height = height;
                const ctx = canvas.getContext('2d');
                ctx.drawImage(img, 0, 0, width, height);
                
                // Comprimir a JPEG con calidad 0.75 para evitar errores de cuota excedida
                const dataUrl = canvas.toDataURL('image/jpeg', 0.75);
                callback(dataUrl);
            } catch (err) {
                callback(rawData);
            }
        };
        img.onerror = function () {
            callback(rawData);
        };
        img.src = rawData;
    };
    reader.onerror = function () {
        console.error("Error al leer archivo en comprimirYConvertirImagen");
    };
    reader.readAsDataURL(file);
}

function handleVoucherUpload(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const previewContainer = document.getElementById("voucher-preview-container");
  const previewImg = document.getElementById("voucher-preview-img");
  const fileNameEl = document.getElementById("voucher-file-name");

  const startTime = performance.now();
  if (typeof showToast === 'function') {
    showToast("⏱️ Optimizando comprobante...");
  }

  comprimirYConvertirImagen(file, function(dataUrl) {
    uploadedVoucherBase64 = dataUrl;
    if (previewImg) previewImg.src = uploadedVoucherBase64;
    const totalSec = ((performance.now() - startTime) / 1000).toFixed(1);
    if (fileNameEl) fileNameEl.textContent = `${file.name} (⏱️ ${totalSec}s · Comprimido)`;
    previewContainer?.classList.remove("hidden");
    if (typeof showToast === 'function') {
      showToast(`⏱️ Comprobante optimizado en ${totalSec}s y listo para enviar ✅`);
    }
  });
}

function removeVoucher() {
  uploadedVoucherBase64 = null;
  const previewContainer = document.getElementById("voucher-preview-container");
  const fileInput = document.getElementById("voucher-file-input");
  if (previewContainer) previewContainer.classList.add("hidden");
  if (fileInput) fileInput.value = "";
}

let currentOrderWhatsappMessage = "";

function copyOrderMessageToClipboard() {
  if (!currentOrderWhatsappMessage) return;
  navigator.clipboard.writeText(currentOrderWhatsappMessage).then(() => {
    const btn = document.getElementById("btn-copy-order-msg");
    if (btn) {
      const orig = btn.innerHTML;
      btn.innerHTML = `<i data-lucide="check" class="w-4 h-4 text-emerald-500"></i><span>¡Copiado!</span>`;
      if (window.lucide) window.lucide.createIcons();
      setTimeout(() => {
        btn.innerHTML = orig;
        if (window.lucide) window.lucide.createIcons();
      }, 2500);
    }
    showToast("Datos y fotos del pedido copiados al portapapeles");
  });
}

function updateCheckoutSummary() {
  const totals = window.store.getCartTotals();
  const summaryEl = document.getElementById("checkout-summary-items");
  const subtotalEl = document.getElementById("checkout-subtotal");
  const shippingEl = document.getElementById("checkout-shipping");
  const totalEl = document.getElementById("checkout-total");
  const shippingNoteEl = document.getElementById("checkout-shipping-note");
  const totalLabelEl = document.getElementById("checkout-total-label");
  const cart = window.store.getCart();

  if (summaryEl) {
    summaryEl.innerHTML = cart.map(item => {
      let photoUrl = item.image;
      if (!photoUrl && window.store) {
        const prod = window.store.getProductById(item.productId);
        if (prod && prod.images && prod.images.length > 0) photoUrl = prod.images[0];
      }
      return `
        <div class="flex items-center justify-between py-2 text-xs border-b border-gray-100 dark:border-neutral-700/60 last:border-0 gap-2">
          <div class="flex items-center gap-2.5 min-w-0 pr-2">
            <img src="${photoUrl || 'images/products/bralette-lila-encaje-festoneado.jpg'}" alt="${item.name}" class="w-10 h-10 object-cover rounded-lg border border-gray-200 dark:border-neutral-700 shrink-0" onerror="this.src='images/products/bralette-lila-encaje-festoneado.jpg'">
            <div class="min-w-0">
              <p class="text-theme-main font-semibold truncate">${item.name}</p>
              <div class="flex items-center gap-1.5 text-[11px] text-theme-muted mt-0.5">
                <span class="inline-block px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold text-[10px]">Talla: ${item.size}</span>
                <span>• ${item.quantity} und</span>
              </div>
            </div>
          </div>
          <span class="font-bold text-theme-primary whitespace-nowrap">${window.formatCOP(item.price * item.quantity)}</span>
        </div>
      `;
    }).join("");
  }

  if (subtotalEl) subtotalEl.textContent = window.formatCOP(totals.subtotal);

  const cfg = window.store ? window.store.getConfig() : {};
  const localShippingCost = (cfg.shippingPolicy && cfg.shippingPolicy.bogotaShippingCost) || cfg.shippingCost || 12000;

  if (selectedDeliveryZone === "bogota") {
    if (shippingEl) shippingEl.innerHTML = `<span class="text-gray-900 dark:text-white font-semibold">${window.formatCOP(localShippingCost)}</span> <span class="text-[10px] text-emerald-600 block">(Entrega local Bogotá)</span>`;
    if (totalEl) totalEl.textContent = window.formatCOP(totals.subtotal + localShippingCost);
    if (shippingNoteEl) shippingNoteEl.textContent = "Incluye prendas y entrega local en Bogotá";
    if (totalLabelEl) totalLabelEl.textContent = "Total a Liquidar:";
  } else {
    // Fuera de Bogotá
    if (shippingEl) shippingEl.innerHTML = `<span class="text-amber-600 dark:text-amber-400 font-semibold text-[11px]">Tarifa Transportadora</span> <span class="text-[9.5px] text-gray-500 block">(Sujeto a disponibilidad y empresa de transporte)</span>`;
    if (totalEl) totalEl.innerHTML = `${window.formatCOP(totals.subtotal)} <span class="text-[11px] font-normal text-gray-500 block">+ flete según transportadora</span>`;
    if (shippingNoteEl) shippingNoteEl.textContent = "Pago anticipado de prendas por Nequi. Flete a convenir.";
    if (totalLabelEl) totalLabelEl.textContent = "Total Prendas (Pago Anticipado):";
  }
}

// Validación estricta de formulario de checkout
function validarFormularioCheckout(telefono, direccion, ciudad, departamento) {
    if (!telefono) telefono = "";
    if (!direccion) direccion = "";
    if (!ciudad) ciudad = "";
    if (!departamento) departamento = "";

    // Normalizar teléfono si viene con prefijo +57 o espacios/guiones
    let telLimpio = telefono.trim().replace(/[\s\-\(\)]/g, '');
    if (telLimpio.startsWith('+57')) telLimpio = telLimpio.substring(3);
    else if (telLimpio.startsWith('57') && telLimpio.length === 12) telLimpio = telLimpio.substring(2);

    const regexCelular = /^3[0-9]{9}$/;
    
    if (!regexCelular.test(telLimpio)) {
        alert("⚠️ Por favor ingresa un número de celular colombiano válido (10 dígitos empezando por 3) para coordinar la entrega.");
        return false;
    }
    if (direccion.trim().length < 5) {
        alert("⚠️ Por favor ingresa una dirección de envío más detallada (incluyendo barrio o conjunto).");
        return false;
    }
    if (!ciudad || ciudad.trim() === "") {
        alert("⚠️ Selecciona o escribe tu ciudad de destino.");
        return false;
    }
    if (!departamento || departamento.trim() === "") {
        alert("⚠️ Selecciona o escribe tu departamento de destino.");
        return false;
    }

    // Comprobación de regla: Fuera de Bogotá requiere Pago Anticipado
    const isBogota = ciudad.toLowerCase().includes("bogot") || selectedDeliveryZone === "bogota";
    if (!isBogota && selectedPaymentMethod === "cod") {
        alert("⚠️ El Pago Contra Entrega aplica exclusivamente para entregas dentro de Bogotá D.C.\n\nPara envíos fuera de Bogotá, los pedidos se despachan con Pago Anticipado por Nequi, y el costo del flete depende de la disponibilidad y tarifa de la empresa transportadora.");
        selectPaymentMethod("transfer");
        return false;
    }

    return true;
}

// Envío y Confirmación de la Orden
function processCheckout(event) {
  event.preventDefault();

  // 0. Validación de Consentimiento de Privacidad y Términos (Ley 1581 de 2012)
  const consentCheckbox = document.getElementById("checkout-consent-checkbox");
  if (consentCheckbox && !consentCheckbox.checked) {
    alert("⚠️ Para continuar debes autorizar el tratamiento de datos y aceptar los Términos y Condiciones.");
    consentCheckbox.focus();
    return;
  }

  const name = document.getElementById("checkout-name")?.value.trim() || "";
  const phone = document.getElementById("checkout-phone")?.value.trim() || "";
  const address = document.getElementById("checkout-address")?.value.trim() || "";
  const city = document.getElementById("checkout-city")?.value.trim() || "";
  const department = document.getElementById("checkout-department")?.value.trim() || "";
  const notes = document.getElementById("checkout-notes")?.value.trim() || "Ninguna";

  if (!name) {
    alert("⚠️ Por favor ingresa tu nombre completo.");
    return;
  }

  // Validación estricta del teléfono, dirección, ciudad y departamento
  if (!validarFormularioCheckout(phone, address, city, department)) {
    return;
  }

  if (selectedPaymentMethod === "transfer" && !uploadedVoucherBase64) {
    const confirmWithoutVoucher = confirm("No has adjuntado el comprobante de transferencia bancaria Nequi. ¿Deseas enviar el pedido y adjuntarlo luego en el chat de WhatsApp?");
    if (!confirmWithoutVoucher) return;
  }

  const isBogota = selectedDeliveryZone === "bogota" || city.toLowerCase().includes("bogot");
  const cfg = window.store ? window.store.getConfig() : {};
  const localShippingCost = (cfg.shippingPolicy && cfg.shippingPolicy.bogotaShippingCost) || cfg.shippingCost || 12000;

  const cart = window.store.getCart();
  const totals = window.store.getCartTotals();

  const finalTotals = {
    subtotal: totals.subtotal,
    count: totals.count,
    shippingCost: isBogota ? localShippingCost : 0,
    shippingType: isBogota ? "Local Bogotá" : "Nacional Transportadora",
    total: isBogota ? (totals.subtotal + localShippingCost) : totals.subtotal
  };

  const orderData = {
    customer: { name, phone, address, city, department, notes, isBogota },
    deliveryZone: isBogota ? "Bogotá D.C." : "Fuera de Bogotá (Nacional)",
    paymentMethod: selectedPaymentMethod === "cod" ? "Pago Contra Entrega (Bogotá)" : `Transferencia Bancaria (${selectedBank.toUpperCase()} - Pago Anticipado)`,
    hasVoucher: Boolean(uploadedVoucherBase64),
    voucher: uploadedVoucherBase64 || null,
    voucherUrl: uploadedVoucherBase64 || null,
    voucherSnippet: uploadedVoucherBase64 ? uploadedVoucherBase64.substring(0, 50) + "..." : null,
    items: cart,
    totals: finalTotals
  };

  const savedOrder = window.store.saveOrder(orderData);

  // Helper para obtener URL base de la tienda
  const getBaseStoreUrl = () => {
    try {
      if (typeof window !== 'undefined' && window.location && window.location.origin) {
        const origin = window.location.origin;
        if (origin !== 'null' && !origin.startsWith('file:')) {
          const path = (window.location.pathname || '').replace(/\/index\.html$/i, '').replace(/\/+$/, '');
          return `${origin}${path}`;
        }
      }
    } catch (e) {}
    return 'http://localhost:3000';
  };
  const baseUrl = getBaseStoreUrl();

  // Genera el desglose con Talla, Foto y Link directo de cada prenda para el proveedor
  const itemsText = cart.map((item, idx) => {
    const prodId = item.productId || "";
    const prodLink = prodId ? `${baseUrl}/index.html?producto=${encodeURIComponent(prodId)}` : "";

    let photoUrl = item.image || "";
    if (!photoUrl && window.store && prodId) {
      const prod = window.store.getProductById(prodId);
      if (prod && Array.isArray(prod.images) && prod.images.length > 0) {
        photoUrl = prod.images[0] || "";
      }
    }

    let fullPhotoUrl = "";
    if (photoUrl) {
      if (photoUrl.startsWith("http://") || photoUrl.startsWith("https://")) {
        fullPhotoUrl = photoUrl;
      } else {
        const cleanPath = photoUrl.startsWith("/") ? photoUrl.substring(1) : photoUrl;
        fullPhotoUrl = `${baseUrl}/${cleanPath}`;
      }
    }

    let linkLines = "";
    if (prodLink) {
      linkLines += `\n   • 🔗 *Link del Producto:* ${prodLink}`;
    }
    if (fullPhotoUrl) {
      linkLines += `\n   • 📸 *Foto Referencia:* ${fullPhotoUrl}`;
    }

    return `${idx + 1}️⃣ *${item.name.toUpperCase()}*
   • 📏 *TALLA ELEGIDA:* *${item.size || 'Única'}*
   • 🔢 *Cantidad:* ${item.quantity} unidad(es)
   • 💵 *Precio:* ${window.formatCOP(item.price * item.quantity)}${linkLines}`;
  }).join("\n\n");

  const storeName = cfg.storeName || "DULCE SECRETO";
  const rawTargetPhone = (cfg.customerService && cfg.customerService.agent1Wa) ? cfg.customerService.agent1Wa : "573132393554";
  const cleanTargetPhone = rawTargetPhone.replace(/[^0-9]/g, '');
  const targetPhone = cleanTargetPhone.startsWith("57") ? cleanTargetPhone : `57${cleanTargetPhone}`;

  let deliveryBlock = "";
  let paymentSummaryBlock = "";

  if (isBogota) {
    deliveryBlock = 
`📍 *DATOS DE LA ENTREGA — BOGOTÁ D.C. (COBERTURA LOCAL):*
• 👤 *Nombre de la Clienta:* ${name}
• 📱 *Celular / WhatsApp:* ${phone}
• 🏙️ *Ciudad:* Bogotá D.C.
• 🗺️ *Departamento / Zona:* ${department}
• 🏠 *Dirección de Entrega:* ${address}
• 📝 *Notas de Entrega:* ${notes}`;

    paymentSummaryBlock = 
`💰 *RESUMEN DE PAGO (BOGOTÁ):*
• 📦 *Subtotal Prendas:* ${window.formatCOP(finalTotals.subtotal)}
• 🛵 *Envío Local Bogotá:* ${window.formatCOP(finalTotals.shippingCost)}
• 🏷️ *TOTAL A LIQUIDAR:* *${window.formatCOP(finalTotals.total)}*

💳 *MÉTODO DE PAGO:* ${selectedPaymentMethod === 'cod' ? '💵 *PAGO CONTRA ENTREGA (Pagas en efectivo al recibir en Bogotá)*' : '📱 *TRANSFERENCIA BANCARIA NEQUI (Pago Anticipado)*'}
${selectedPaymentMethod === 'cod' ? '✓ Cancela al mensajero en la puerta de tu domicilio en Bogotá.' : (uploadedVoucherBase64 ? '📸 *Comprobante Nequi:* Adjuntado en la orden web.' : '⚠️ *Comprobante Nequi:* Te adjunto la foto de la transferencia por este chat.')}`;
  } else {
    deliveryBlock = 
`📍 *DATOS DE LA ENTREGA — NACIONAL (FUERA DE BOGOTÁ):*
• 👤 *Nombre de la Clienta:* ${name}
• 📱 *Celular / WhatsApp:* ${phone}
• 🏙️ *Ciudad / Municipio:* ${city}
• 🗺️ *Departamento:* ${department}
• 🏠 *Dirección de Entrega:* ${address}
• 📝 *Notas para la transportadora:* ${notes}`;

    paymentSummaryBlock = 
`💰 *RESUMEN DE PAGO (FUERA DE BOGOTÁ):*
• 📦 *Subtotal Prendas (Pago Anticipado):* *${window.formatCOP(finalTotals.subtotal)}*
• 🚚 *Flete / Envío:* *Sujeto a disponibilidad y tarifa de la empresa transportadora* (Interrapidísimo / Servientrega / Envía)

💳 *MÉTODO DE PAGO:* 📱 *PAGO ANTICIPADO OBLIGATORIO (Nequi Oficial: 311 882 1629)*
${uploadedVoucherBase64 ? "📸 *Comprobante de Pago:* Adjuntado en la orden web (te lo comparto a continuación)." : "⚠️ *Comprobante:* Te adjunto la foto de la transferencia por este chat."}`;
  }

  const message = 
`✨🛍️ *NUEVO PEDIDO CONFIRMADO — ${storeName.toUpperCase()}* 🛍️✨
━━━━━━━━━━━━━━━━━━━━━
*Orden N°:* #${savedOrder.id}
*Fecha:* ${new Date().toLocaleDateString('es-CO')} ${new Date().toLocaleTimeString('es-CO', { hour: '2-digit', minute: '2-digit' })}

${deliveryBlock}

👙 *PRENDA(S) SELECCIONADA(S):*
━━━━━━━━━━━━━━━━━━━━━
${itemsText}
━━━━━━━━━━━━━━━━━━━━━

${paymentSummaryBlock}

🔒 *Garantía:* Empaque 100% discreto y confidencial sin logos externos.`;

  currentOrderWhatsappMessage = message;
  const encodedMsg = encodeURIComponent(message);
  const whatsappUrl = `https://wa.me/${targetPhone}?text=${encodedMsg}`;

  // Limpia carrito y cierra modal de checkout
  window.store.clearCart();
  closeCheckoutModal();

  // Muestra pantalla de éxito
  showOrderSuccessModal(savedOrder, whatsappUrl, orderData.paymentMethod, message);
}

function showOrderSuccessModal(order, whatsappUrl, paymentMethod, rawMessage) {
  const successModal = document.getElementById("order-success-modal");
  const orderIdSpan = document.getElementById("success-order-id");
  const orderPaymentSpan = document.getElementById("success-payment-method");
  const waBtn = document.getElementById("success-whatsapp-btn");
  const itemsPreview = document.getElementById("success-order-items-preview");
  const deliveryPreview = document.getElementById("success-customer-delivery-preview");

  if (orderIdSpan) orderIdSpan.textContent = `#${order.id || order}`;
  if (orderPaymentSpan) orderPaymentSpan.textContent = paymentMethod;
  if (waBtn) {
    waBtn.href = whatsappUrl;
    waBtn.target = "_blank";
  }

  // Renderizar las prendas solicitadas con foto y talla
  if (itemsPreview && Array.isArray(order.items)) {
    itemsPreview.innerHTML = order.items.map(item => `
      <div class="flex items-center gap-3 py-1.5 border-b border-gray-100 dark:border-neutral-700/60 last:border-0">
        <img src="${item.image || 'images/products/bralette-lila-encaje-festoneado.jpg'}" alt="${item.name}" class="w-12 h-12 object-cover rounded-lg border border-gray-200 dark:border-neutral-700 shrink-0" onerror="this.src='images/products/bralette-lila-encaje-festoneado.jpg'">
        <div class="min-w-0 flex-1">
          <p class="font-bold text-gray-900 dark:text-white truncate text-xs">${item.name}</p>
          <div class="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-neutral-400 mt-0.5">
            <span class="inline-block px-1.5 py-0.5 rounded bg-rose-100 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 font-bold">Talla: ${item.size}</span>
            <span>• Cant: ${item.quantity}</span>
          </div>
        </div>
      </div>
    `).join("");
  }

  // Renderizar los datos de entrega
  if (deliveryPreview && order.customer) {
    deliveryPreview.innerHTML = `
      <p class="font-bold text-gray-900 dark:text-white mb-1">📍 Datos de Entrega Confirmados:</p>
      <p><strong>Destinataria:</strong> ${order.customer.name} (Tel: ${order.customer.phone})</p>
      <p><strong>Dirección:</strong> ${order.customer.address}, ${order.customer.city} (${order.customer.department})</p>
      ${order.customer.notes ? `<p><strong>Indicaciones:</strong> <em>${order.customer.notes}</em></p>` : ''}
    `;
  }

  if (successModal) {
    successModal.classList.remove("hidden");
    document.body.style.overflow = "hidden";
  }

  if (window.lucide) window.lucide.createIcons();

  // Abre automáticamente WhatsApp tras breve pausa
  setTimeout(() => {
    window.open(whatsappUrl, '_blank');
  }, 1000);
}

function closeOrderSuccessModal() {
  const successModal = document.getElementById("order-success-modal");
  if (successModal) {
    successModal.classList.add("hidden");
    document.body.style.overflow = "";
  }
}

window.openCheckoutModal = openCheckoutModal;
window.closeCheckoutModal = closeCheckoutModal;
window.selectPaymentMethod = selectPaymentMethod;
window.selectBank = selectBank;
window.copyToClipboard = copyToClipboard;
window.handleVoucherUpload = handleVoucherUpload;
window.removeVoucher = removeVoucher;
window.processCheckout = processCheckout;
window.showOrderSuccessModal = showOrderSuccessModal;
window.closeOrderSuccessModal = closeOrderSuccessModal;
window.copyOrderMessageToClipboard = copyOrderMessageToClipboard;
window.validarFormularioCheckout = validarFormularioCheckout;
window.comprimirYConvertirImagen = comprimirYConvertirImagen;
