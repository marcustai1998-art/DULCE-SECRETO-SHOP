// ==========================================================================
// DULCE SECRETO - BOTÓN MULTI-AGENTE WHATSAPP
// Conexión directa con asesoras de venta y expertas en tallas
// ==========================================================================

function toggleWhatsAppMenu() {
  const menu = document.getElementById("whatsapp-agents-menu");
  if (!menu) return;
  menu.classList.toggle("hidden");
}

function openWhatsAppAgent(phoneNumber, agentName, reason = "general") {
  let text = `¡Hola ${agentName}! ✨ Vengo de la tienda virtual *DULCE SECRETO*. `;

  if (reason === "tallas") {
    text += `Me gustaría recibir asesoría personalizada para confirmar mi talla de lencería.`;
  } else if (reason === "pedido") {
    text += `Tengo una consulta sobre un pedido y los métodos de pago.`;
  } else {
    text += `Quisiera conocer más sobre las colecciones disponibles y promociones activas.`;
  }

  const url = `https://wa.me/${phoneNumber}?text=${encodeURIComponent(text)}`;
  window.open(url, "_blank");

  // Cierra menú
  const menu = document.getElementById("whatsapp-agents-menu");
  if (menu) menu.classList.add("hidden");
}

window.toggleWhatsAppMenu = toggleWhatsAppMenu;
window.openWhatsAppAgent = openWhatsAppAgent;

// Helper para obtener URL base de la tienda
function getBaseStoreUrl() {
  try {
    if (typeof window !== 'undefined' && window.location && window.location.origin) {
      const origin = window.location.origin;
      if (origin !== 'null' && !origin.startsWith('file:')) {
        const path = (window.location.pathname || '').replace(/\/index\.html$/i, '').replace(/\/+$/, '');
        return `${origin}${path}`;
      }
    }
  } catch (e) {}
  return 'http://localhost:3000';
}

// ==========================================================================
// GENERADOR DE MENSAJE WHATSAPP PARA EL CARRITO (PEDIDO A DULCE / PROVEEDOR)
// ==========================================================================
function generarMensajeWhatsAppCarrito() {
    let carrito = [];
    try {
        carrito = JSON.parse(localStorage.getItem('dulce_secreto_cart')) || [];
    } catch (e) {
        carrito = [];
    }
    if ((!carrito || carrito.length === 0) && window.store && typeof window.store.getCart === 'function') {
        carrito = window.store.getCart() || [];
    }

    if (!carrito || carrito.length === 0) {
        alert("Tu bolsa de compras está vacía.");
        return;
    }
    
    const baseUrl = getBaseStoreUrl();
    let mensaje = "Hola DULCE 👋, deseo confirmar mi pedido de DULCE SECRETO:\n\n";
    let total = 0;
    
    carrito.forEach((item, index) => {
        const nombre = item.nombre || item.name || 'Prenda';
        const precio = Number(item.precio !== undefined ? item.precio : (item.price || 0));
        const cantidad = Number(item.cantidad !== undefined ? item.cantidad : (item.quantity || 1));
        const talla = item.talla || item.size || 'Única';
        const prodId = item.productId || item.id || '';
        const subtotal = precio * cantidad;
        total += subtotal;

        // Links de producto y foto para el proveedor
        const linkPrenda = prodId ? `${baseUrl}/index.html?producto=${encodeURIComponent(prodId)}` : '';
        let photoUrl = item.image || item.imagen || '';
        if (!photoUrl && window.store && prodId) {
            const prod = window.store.getProductById(prodId);
            if (prod && Array.isArray(prod.images) && prod.images.length > 0) {
                photoUrl = prod.images[0] || '';
            }
        }
        let fullPhotoUrl = '';
        if (photoUrl) {
            if (photoUrl.startsWith('http://') || photoUrl.startsWith('https://')) {
                fullPhotoUrl = photoUrl;
            } else {
                const clean = photoUrl.startsWith('/') ? photoUrl.substring(1) : photoUrl;
                fullPhotoUrl = `${baseUrl}/${clean}`;
            }
        }

        mensaje += `${index + 1}️⃣ *${nombre.toUpperCase()}*\n`;
        mensaje += `   • 📏 *Talla:* ${talla}\n`;
        mensaje += `   • 🔢 *Cantidad:* ${cantidad} unidad(es)\n`;
        mensaje += `   • 💵 *Subtotal:* $${subtotal.toLocaleString('es-CO')} COP\n`;
        if (linkPrenda) {
            mensaje += `   • 🔗 *Link del Producto:* ${linkPrenda}\n`;
        }
        if (fullPhotoUrl) {
            mensaje += `   • 📸 *Foto Referencia:* ${fullPhotoUrl}\n`;
        }
        mensaje += `\n`;
    });
    
    mensaje += `━━━━━━━━━━━━━━━━━━━━━\n`;
    mensaje += `💰 *Total a Pagar:* $${total.toLocaleString('es-CO')} COP\n`;
    mensaje += `📦 *Método de pago:* Contra Entrega / Transferencia\n`;
    mensaje += `🔒 *Empaque:* 100% discreto y confidencial\n`;
    mensaje += `¡Quedo a la espera de las instrucciones de envío! ✨`;
    
    const telefonoDulce = localStorage.getItem('whatsapp_dulce') || (window.store && window.store.getConfig && window.store.getConfig().customerService?.agent1Wa) || '573132393554';
    const urlWhatsApp = `https://wa.me/${telefonoDulce}?text=${encodeURIComponent(mensaje)}`;
    window.open(urlWhatsApp, '_blank');
}

window.generarMensajeWhatsAppCarrito = generarMensajeWhatsAppCarrito;
