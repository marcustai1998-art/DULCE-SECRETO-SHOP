// ==========================================================================
// DULCE SECRETO - CARRITO LATERAL (DRAWER) Y VENTA CRUZADA
// ==========================================================================

function renderCartDrawer() {
  const cartContainer = document.getElementById("cart-items-container");
  const cartSubtotalEl = document.getElementById("cart-subtotal");
  const cartShippingEl = document.getElementById("cart-shipping");
  const cartTotalEl = document.getElementById("cart-total");
  const cartBadgeCountEl = document.getElementById("cart-badge-count");
  const mobileCartBadgeEl = document.getElementById("mobile-cart-badge");
  const shippingProgressBar = document.getElementById("shipping-progress-bar");
  const shippingProgressText = document.getElementById("shipping-progress-text");
  const crossSellContainer = document.getElementById("cart-cross-sell");

  if (!cartContainer) return;

  const cart = window.store.getCart();
  const totals = window.store.getCartTotals();

  // Badges (Mobile & Desktop)
  document.querySelectorAll(".cart-badge-count, #cart-badge-count, #cart-badge-count-mobile, #mobile-cart-badge").forEach(el => {
    el.textContent = totals.count;
    el.classList.toggle("hidden", totals.count === 0);
  });

  // Mensaje de Confidencialidad y Envío
  if (shippingProgressText) {
    shippingProgressText.innerHTML = `🔒 <strong>Empaque discreto</strong> · Contra entrega en Bogotá · Fuera de Bogotá con pago anticipado.`;
  }
  if (shippingProgressBar && shippingProgressBar.parentElement) {
    shippingProgressBar.parentElement.style.display = "none";
  }

  // Totales
  if (cartSubtotalEl) cartSubtotalEl.textContent = window.formatCOP(totals.subtotal);
  if (cartShippingEl) cartShippingEl.textContent = totals.count === 0 ? "$ 0" : window.formatCOP(totals.shippingCost);
  if (cartTotalEl) cartTotalEl.textContent = window.formatCOP(totals.total);

  // Lista de items
  if (cart.length === 0) {
    cartContainer.innerHTML = `
      <div class="text-center py-12 px-4">
        <div class="w-20 h-20 mx-auto mb-4 rounded-full bg-theme-muted flex items-center justify-center text-theme-primary">
          <i data-lucide="shopping-bag" class="w-10 h-10"></i>
        </div>
        <h3 class="text-lg font-bold text-theme-main">Tu carrito está vacío</h3>
        <p class="text-sm text-theme-muted mt-1 max-w-xs mx-auto">Explora nuestras colecciones exclusivas de encaje y seda para consentirte hoy.</p>
        <button onclick="toggleCartDrawer(false)" class="mt-6 px-6 py-2.5 rounded-full btn-primary-theme text-sm font-semibold shadow-md">
          Explorar Colección
        </button>
      </div>
    `;
    if (crossSellContainer) crossSellContainer.innerHTML = "";
    if (window.lucide) window.lucide.createIcons();
    return;
  }

  cartContainer.innerHTML = cart.map(item => `
    <div class="flex gap-3 py-3 border-b border-theme last:border-0 items-start">
      <img src="${item.image}" alt="${item.name}" class="w-20 h-24 object-cover rounded-lg border border-theme flex-shrink-0 shadow-sm" />
      <div class="flex-1 min-w-0">
        <div class="flex justify-between items-start gap-2">
          <h4 class="text-sm font-medium text-theme-main line-clamp-2">${item.name}</h4>
          <button onclick="window.store.removeFromCart('${item.cartItemId}')" class="text-gray-400 hover:text-red-500 transition-colors p-1" title="Eliminar">
            <i data-lucide="trash-2" class="w-4 h-4"></i>
          </button>
        </div>
        
        <div class="flex flex-wrap items-center gap-1.5 mt-1 text-xs">
          <span class="inline-flex items-center px-2 py-0.5 rounded-full bg-theme-muted font-medium text-theme-main border border-theme">
            Talla: ${item.size}
          </span>
        </div>

        <div class="flex justify-between items-center mt-3">
          <div class="flex items-center border border-theme rounded-lg bg-theme-card">
            <button onclick="changeCartItemQty('${item.cartItemId}', -1)" class="w-7 h-7 flex items-center justify-center text-theme-main hover:bg-theme-muted rounded-l-lg transition-colors font-bold text-sm">
              -
            </button>
            <span class="w-8 text-center text-xs font-semibold text-theme-main">${item.quantity}</span>
            <button onclick="changeCartItemQty('${item.cartItemId}', 1)" class="w-7 h-7 flex items-center justify-center text-theme-main hover:bg-theme-muted rounded-r-lg transition-colors font-bold text-sm">
              +
            </button>
          </div>
          <span class="font-bold text-sm text-theme-primary">${window.formatCOP(item.price * item.quantity)}</span>
        </div>
      </div>
    </div>
  `).join("");

  // Venta Cruzada (Cross-selling) en el carrito
  if (crossSellContainer) {
    const products = window.store.getProducts();
    const cartProductIds = cart.map(i => i.productId);
    const crossSellProducts = products.filter(p => !cartProductIds.includes(p.id)).slice(0, 2);

    if (crossSellProducts.length > 0) {
      crossSellContainer.innerHTML = `
        <div class="pt-3 border-t border-theme">
          <div class="flex items-center justify-between mb-2">
            <span class="text-xs font-bold uppercase tracking-wider text-theme-primary flex items-center gap-1">
              <i data-lucide="sparkles" class="w-3.5 h-3.5"></i> Combínalo con:
            </span>
          </div>
          <div class="space-y-2">
            ${crossSellProducts.map(p => `
              <div class="flex items-center justify-between p-2 rounded-lg bg-theme-muted border border-theme text-xs">
                <img src="${p.images[0]}" class="w-10 h-12 object-cover rounded shadow-sm mr-2" />
                <div class="flex-1 min-w-0 pr-2">
                  <p class="font-semibold text-theme-main truncate">${p.name}</p>
                  <p class="text-theme-primary font-bold">${window.formatCOP(p.salePrice || p.regularPrice)}</p>
                </div>
                <button onclick="quickAddCrossSell('${p.id}')" class="px-2.5 py-1.5 rounded-full btn-primary-theme font-medium text-[11px] whitespace-nowrap shadow-sm">
                  + Agregar
                </button>
              </div>
            `).join("")}
          </div>
        </div>
      `;
    } else {
      crossSellContainer.innerHTML = "";
    }
  }

  if (window.lucide) window.lucide.createIcons();
}

function changeCartItemQty(cartItemId, delta) {
  const cart = window.store.getCart();
  const item = cart.find(i => i.cartItemId === cartItemId);
  if (!item) return;
  const newQty = item.quantity + delta;
  if (newQty <= 0) {
    window.store.removeFromCart(cartItemId);
  } else {
    window.store.updateCartItem(cartItemId, { quantity: newQty });
  }
}

function quickAddCrossSell(productId) {
  const product = window.store.getProductById(productId);
  if (!product) return;
  const defaultSize = (product.sizes && product.sizes[0]) ? product.sizes[0] : "Única";
  window.store.addToCart(productId, defaultSize, "", 1);
  showToast(`¡${product.name} agregado al carrito! ✨`);
}

function toggleCartDrawer(open) {
  const drawer = document.getElementById("cart-drawer");
  const backdrop = document.getElementById("cart-backdrop");
  if (!drawer || !backdrop) return;

  if (open) {
    drawer.classList.remove("translate-x-full");
    backdrop.classList.remove("hidden");
    document.body.style.overflow = "hidden";
    renderCartDrawer();
  } else {
    drawer.classList.add("translate-x-full");
    backdrop.classList.add("hidden");
    document.body.style.overflow = "";
  }
}

function showToast(message, duration = 3000) {
  let container = document.getElementById("dulceToastContainer");
  if (!container) {
    container = document.createElement("div");
    container.id = "dulceToastContainer";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  toast.className = "dulce-toast flex items-center gap-2.5";
  toast.innerHTML = `<span class="text-rose-400">✨</span> <span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.transition = "opacity 0.3s ease, transform 0.3s ease";
    toast.style.opacity = "0";
    toast.style.transform = "translateX(100%)";
    setTimeout(() => toast.remove(), 320);
  }, duration);
}

// Suscribe el render al motor de carrito
window.addEventListener("DOMContentLoaded", () => {
  window.store.subscribeCart(() => renderCartDrawer());
  renderCartDrawer();
});

window.renderCartDrawer = renderCartDrawer;
window.toggleCartDrawer = toggleCartDrawer;
window.changeCartItemQty = changeCartItemQty;
window.quickAddCrossSell = quickAddCrossSell;
window.showToast = showToast;
if (typeof generarMensajeWhatsAppCarrito === 'function') {
  window.generarMensajeWhatsAppCarrito = generarMensajeWhatsAppCarrito;
}
