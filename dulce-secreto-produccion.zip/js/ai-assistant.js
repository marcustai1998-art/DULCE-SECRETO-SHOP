// ==========================================================================
// DULCE SECRETO - ASISTENTE DE TALLAS & ESTILO CON IA INTEGRADA
// Calculadora anatómica de copa/banda y Chatbot Asesor de Estilo
// ==========================================================================

const BRA_SIZE_CHART = {
  getBand(underbustCm) {
    if (underbustCm < 68) return "30";
    if (underbustCm <= 72) return "32";
    if (underbustCm <= 77) return "34";
    if (underbustCm <= 82) return "36";
    if (underbustCm <= 87) return "38";
    if (underbustCm <= 93) return "40";
    if (underbustCm <= 100) return "42";
    return "44+";
  },
  getCup(diffCm) {
    if (diffCm <= 11) return "A";
    if (diffCm <= 14) return "B";
    if (diffCm <= 16.5) return "C";
    if (diffCm <= 19) return "D";
    if (diffCm <= 21.5) return "DD";
    return "E+";
  },
  getBottomSize(waistCm, hipCm) {
    if (waistCm <= 67 && hipCm <= 93) return "S";
    if (waistCm <= 75 && hipCm <= 101) return "M";
    if (waistCm <= 83 && hipCm <= 109) return "L";
    if (waistCm <= 92 && hipCm <= 118) return "XL";
    return "XXL";
  }
};

class AIAssistant {
  constructor() {
    this.messages = [];
    this.initDefaultHistory();
  }

  initDefaultHistory() {
    this.messages = [
      {
        sender: "bot",
        text: "¡Hola hermosa! ✨ Bienvenida a <strong>DULCE SECRETO</strong>. Soy tu asesora virtual de estilo y tallas. ¿En qué puedo consentirte hoy?",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      }
    ];
  }

  // Calcula talla exacta según las medidas
  calculateSize(bustCm, underbustCm, waistCm, hipCm) {
    const band = BRA_SIZE_CHART.getBand(underbustCm);
    const diff = Math.max(0, bustCm - underbustCm);
    const cup = BRA_SIZE_CHART.getCup(diff);
    const bottom = BRA_SIZE_CHART.getBottomSize(waistCm, hipCm);
    const fullBraSize = `${band}${cup}`;

    let recommendations = [];
    if (fullBraSize.includes("B") || fullBraSize.includes("C")) {
      recommendations.push("Conjunto Bralette 'Tentación Francesa' Strappy");
      recommendations.push("Babydoll Encaje Chantilly 'Noche Secreta'");
    } else {
      recommendations.push("Corset Modelador 'Aura de Reina'");
      recommendations.push("Bodysuit 'Pecado Capital'");
    }

    return {
      braSize: fullBraSize,
      bottomSize: bottom,
      band,
      cup,
      diff,
      recommendations,
      explanation: `Tu contorno de torso (${underbustCm} cm) corresponde a <strong>Banda ${band}</strong>, y tu realce de busto (${diff.toFixed(1)} cm de diferencia) corresponde a <strong>Copa ${cup}</strong>. Para panties, ligueros o bodies, tu talla sugerida según cintura (${waistCm} cm) y cadera (${hipCm} cm) es <strong>Talla ${bottom}</strong>.`
    };
  }

  // Genera respuesta conversacional
  respondToPrompt(promptText) {
    const text = promptText.toLowerCase().trim();

    // 1. Consulta de Tallas
    if (text.includes("talla") || text.includes("medir") || text.includes("bra") || text.includes("copa")) {
      return {
        text: "¡Con gusto te ayudo a encontrar tu talla perfecta! 📐 En lencería fina, la talla se compone de dos medidas claves: <strong>Busto</strong> y <strong>Bajo Busto</strong>.<br><br>💡 <em>Haz clic abajo en el botón <strong>'Calcular mi Talla Exacta'</strong> para ingresar tus medidas en centímetros y te diré tu talla de copa y panty de inmediato.</em>",
        action: "OPEN_CALCULATOR"
      };
    }

    // 2. Recomendación para Ocasión Especial
    if (text.includes("noche") || text.includes("especial") || text.includes("sexy") || text.includes("pareja") || text.includes("recomienda")) {
      return {
        text: "¡Uff, para una noche inolvidable te recomiendo combinar dos de nuestros favoritos virales! 🔥<br><br>1️⃣ <strong>Babydoll Encaje Chantilly 'Noche Secreta'</strong> (en tono Rojo Pasión o Negro Secreto).<br>2️⃣ Combínalo con el <strong>Set Liguero 'Diosa de Medianoche'</strong> con medias de encaje.<br><br>¡Es la combinación de mayor impacto visual y confort garantizado! ✨",
        action: "VIEW_FEATURED"
      };
    }

    // 3. Pago Contra Entrega & Cobertura
    if (text.includes("contra entrega") || text.includes("cod") || text.includes("recibir") || text.includes("pagar en casa") || text.includes("bogota") || text.includes("bogotá")) {
      return {
        text: "🛵 <strong>Envíos en Bogotá D.C.:</strong> ¡Sí! Contamos con servicio de <strong>Pago Contra Entrega</strong> dentro de Bogotá. Recibes en la puerta de tu casa u oficina y cancelas en efectivo.<br><br>📦 <strong>Envíos Fuera de Bogotá:</strong> Para despachos a nivel nacional se requiere <strong>Pago Anticipado</strong> (Nequi), y el precio del flete depende de la tarifa y disponibilidad de la empresa transportadora."
      };
    }

    // 4. Métodos Bancarios
    if (text.includes("nequi") || text.includes("transferencia") || text.includes("pago") || text.includes("cuenta") || text.includes("banco")) {
      return {
        text: "Aceptamos pagos 100% seguros y directos por: <br>📱 <strong>Nequi Oficial:</strong> 311 882 1629 (Dulce Secreto Boutique SAS) — <em>Válido para todo el país y obligatorio para envíos fuera de Bogotá</em>.<br>💵 <strong>Pago Contra Entrega:</strong> Disponible para entregas dentro de <strong>Bogotá D.C.</strong><br><br>Al finalizar tu orden puedes adjuntar el comprobante y el sistema te conectará de inmediato con nuestra línea oficial de WhatsApp."
      };
    }

    // 5. Envíos, Tiempos y Fletes
    if (text.includes("envio") || text.includes("envío") || text.includes("flete") || text.includes("despacho") || text.includes("costo")) {
      return {
        text: "🚚 <strong>Políticas de Envío Dulce Secreto:</strong><br>• <strong>Dentro de Bogotá:</strong> Entregas locales rápidas con opción de Pago Contra Entrega.<br>• <strong>Fuera de Bogotá (Nacional):</strong> Despachos con <strong>Pago Anticipado</strong>. El precio del envío se liquida según la <strong>disponibilidad y tarifa de la empresa transportadora</strong> (Interrapidísimo / Servientrega / Envía).<br>🔒 Todos los paquetes viajan en empaque 100% confidencial y discreto."
      };
    }

    // Respuesta por defecto
    return {
      text: `Entiendo tu inquietud sobre: "${promptText}". ¿Te gustaría que una de nuestras asesoras te atienda de inmediato por WhatsApp, o prefieres que calculemos tu talla aquí mismo?`,
      action: "WHATSAPP_REDIRECT"
    };
  }
}

const aiAssistant = new AIAssistant();
window.aiAssistant = aiAssistant;
