/**
 * ============================================================================
 * DULCE SECRETO — COIL IMAGE LOADER & CACHE MANAGER (WEB EDITION)
 * Arquitectura de Caché de Imágenes Multinivel inspirada en Coil (Android / KMP):
 * - L1: Memory Cache en RAM (LRU con Blobs / ObjectURLs)
 * - L2: Persistent Disk Cache (CacheStorage API & Service Worker)
 * - Precarga Asíncrona en Idle Time (Pre-warming de Catálogo)
 * - Soporte de Crossfade y Transiciones Fluidas
 * ============================================================================
 */

(function (window) {
  'use strict';

  const CACHE_NAME = 'dulce-secreto-coil-images-v1';
  const MAX_MEMORY_ENTRIES = 60; // Límite de prendas en memoria RAM

  class CoilImageLoader {
    constructor() {
      // L1: Memory Cache (RAM)
      this.memoryCache = new Map();
      
      // Estadísticas de Rendimiento
      this.stats = {
        memoryHits: 0,
        diskHits: 0,
        networkFetches: 0,
        errors: 0
      };

      // Registro de Service Worker para el L2 Disk Cache
      this.initServiceWorker();
    }

    /**
     * Inicializa el Service Worker para persistencia de disco entre sesiones
     */
    initServiceWorker() {
      if ('serviceWorker' in navigator && window.location.protocol.startsWith('http')) {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('/sw.js')
            .then((reg) => {
              console.log('⚡ [Coil:DiskCache] Service Worker activo y sincronizado:', reg.scope);
            })
            .catch((err) => {
              console.warn('[Coil:DiskCache] Aviso: Service Worker no registrado (modo local/estático):', err.message);
            });
        });
      }
    }

    /**
     * Guarda una imagen en L1 Memory Cache con política de expulsión LRU
     */
    putInMemory(url, objectUrl) {
      if (this.memoryCache.has(url)) {
        this.memoryCache.delete(url);
      } else if (this.memoryCache.size >= MAX_MEMORY_ENTRIES) {
        // Expulsa el elemento menos recientemente usado (LRU)
        const oldestKey = this.memoryCache.keys().next().value;
        const oldObjectUrl = this.memoryCache.get(oldestKey);
        if (oldObjectUrl && oldObjectUrl.startsWith('blob:')) {
          URL.revokeObjectURL(oldObjectUrl);
        }
        this.memoryCache.delete(oldestKey);
      }
      this.memoryCache.set(url, objectUrl);
    }

    /**
     * Carga una imagen resolviendo primero en L1 (RAM), luego L2 (Disco) y finalmente Red
     * @param {string} url - URL relativa o absoluta de la imagen
     * @returns {Promise<string>} - URL lista para usar en el atributo src de un <img>
     */
    async load(url) {
      if (!url) return '';

      // 1. NIVEL L1: Búsqueda en Memory Cache (RAM) — Latencia ~0ms
      if (this.memoryCache.has(url)) {
        this.stats.memoryHits++;
        const cached = this.memoryCache.get(url);
        // Mover al final para LRU
        this.memoryCache.delete(url);
        this.memoryCache.set(url, cached);
        return cached;
      }

      // 2. NIVEL L2: Búsqueda en Persistent Disk Cache (CacheStorage API) — Latencia ~1-5ms
      if ('caches' in window) {
        try {
          const cache = await caches.open(CACHE_NAME);
          const response = await cache.match(url);
          if (response && response.ok) {
            this.stats.diskHits++;
            const blob = await response.blob();
            const objectUrl = URL.createObjectURL(blob);
            this.putInMemory(url, objectUrl);
            return objectUrl;
          }
        } catch (e) {
          // Ignorar y continuar a red
        }
      }

      // 3. NIVEL L3: Descarga por Red (Network Fetch)
      this.stats.networkFetches++;
      try {
        const fetchResponse = await fetch(url);
        if (!fetchResponse.ok) throw new Error(`HTTP ${fetchResponse.status}`);

        // Guardar clon en L2 Disk Cache
        if ('caches' in window) {
          try {
            const cache = await caches.open(CACHE_NAME);
            cache.put(url, fetchResponse.clone());
          } catch (e) {}
        }

        const blob = await fetchResponse.blob();
        const objectUrl = URL.createObjectURL(blob);
        this.putInMemory(url, objectUrl);
        return objectUrl;
      } catch (err) {
        this.stats.errors++;
        // Fallback seguro: retornar la URL original para que el navegador intente su carga estándar
        return url;
      }
    }

    /**
     * Aplica la imagen a un elemento <img> con soporte de crossfade fluido (estilo Coil)
     * @param {HTMLImageElement} imgElement 
     * @param {string} src 
     * @param {Object} options - { crossfade: true, placeholder: '' }
     */
    async bind(imgElement, src, options = { crossfade: true }) {
      if (!imgElement || !src) return;

      if (options.placeholder && !imgElement.src) {
        imgElement.src = options.placeholder;
      }

      const resolvedSrc = await this.load(src);

      if (options.crossfade) {
        imgElement.style.transition = 'opacity 0.25s ease-in-out';
        imgElement.style.opacity = '0.7';
      }

      imgElement.src = resolvedSrc;

      if (options.crossfade) {
        imgElement.onload = () => {
          imgElement.style.opacity = '1';
        };
      }
    }

    /**
     * Precarga asíncrona de un conjunto de imágenes (Pre-warming)
     * Ejecuta en background (idle time) para que navegar el catálogo sea instantáneo
     * @param {Array<string>} urls 
     */
    preloadCatalog(urls) {
      if (!Array.isArray(urls) || urls.length === 0) return;

      const schedule = window.requestIdleCallback || ((cb) => setTimeout(cb, 200));

      schedule(() => {
        let index = 0;
        const batchSize = 4;

        const processBatch = () => {
          const slice = urls.slice(index, index + batchSize);
          slice.forEach((url) => {
            if (!this.memoryCache.has(url)) {
              this.load(url).catch(() => {});
            }
          });

          index += batchSize;
          if (index < urls.length) {
            schedule(processBatch);
          }
        };

        processBatch();
      });
    }

    /**
     * Obtiene métricas en vivo del rendimiento de la caché
     */
    getStats() {
      return {
        ...this.stats,
        memorySize: this.memoryCache.size,
        maxMemory: MAX_MEMORY_ENTRIES,
        hitRatio: (this.stats.memoryHits + this.stats.diskHits) / 
          Math.max(1, (this.stats.memoryHits + this.stats.diskHits + this.stats.networkFetches))
      };
    }
  }

  // Instancia global disponible en window
  window.CoilImageLoader = new CoilImageLoader();

})(typeof window !== 'undefined' ? window : globalThis);
